/**
 * CONTENT SCRIPT - ERP MARKETPLACES INTELIGÊNCIA COMPETITIVA
 * Executa em páginas de produto do Mercado Livre (*.mercadolivre.com.br) e Shopee (*.shopee.com.br).
 * Fornece extração multicamada (Meta Tags SEO Microdata + JSON Estruturado LD+JSON + Seletores DOM Modernos)
 * e botão flutuante ergonômico no padrão Tiny ERP.
 */

(function () {
  "use strict";

  // Previne reinjeção múltipla
  if (window.__CRM_MARKETPLACES_CONTENT_INJECTED__) return;
  window.__CRM_MARKETPLACES_CONTENT_INJECTED__ = true;

  // 1. Detecta se está executando no próprio ERP (Localhost ou Vercel)
  const isErpPage =
    window.location.hostname === "localhost" ||
    window.location.hostname === "127.0.0.1" ||
    window.location.hostname.includes("vercel.app");

  if (isErpPage) {
    const currentErpUrl = window.location.origin;

    // Pareamento automático: se o usuário estiver logado neste ERP, obtém o token
    // de longa duração e repassa ao service worker (sem copiar/colar token).
    const pairWithErp = async () => {
      try {
        const res = await fetch(`${currentErpUrl}/api/extension/token`, { credentials: "include", cache: "no-store" });
        if (!res.ok) return;
        const session = await res.json();
        if (!session?.token) return;

        chrome.runtime.sendMessage(
          { action: "ERP_SESSION", erpUrl: currentErpUrl, token: session.token, user: session.user },
          (status) => {
            if (chrome.runtime.lastError) return;
            window.dispatchEvent(
              new CustomEvent("CRM_EXTENSION_CONNECTED", {
                detail: { online: !!status?.online, user: session.user, origin: currentErpUrl },
              })
            );
          }
        );
      } catch {
        // Não é o ERP ou servidor indisponível: mantém a configuração atual
      }
    };

    pairWithErp();
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") pairWithErp();
    });

    window.__CRM_MARKETPLACES_EXTENSION_ACTIVE__ = true;
    document.documentElement.setAttribute("data-crm-extension-installed", "true");
    window.dispatchEvent(
      new CustomEvent("CRM_EXTENSION_DETECTED", {
        detail: { version: (typeof chrome !== "undefined" && chrome.runtime?.getManifest?.()?.version) || "1.4.0", origin: currentErpUrl },
      })
    );

    window.addEventListener("message", (event) => {
      if (event.data?.type === "CRM_TRIGGER_SEARCH_EXT") {
        const { query, platform } = event.data;
        if (platform === "shopee") {
          window.open(
            `https://shopee.com.br/search?keyword=${encodeURIComponent(query)}#crm_auto_sync=1&erp_url=${encodeURIComponent(currentErpUrl)}`,
            "_blank"
          );
        } else {
          const normQ = (query || "").trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^\w\s-]/g, "").replace(/\s+/g, "-");
          window.open(
            `https://lista.mercadolivre.com.br/${encodeURIComponent(normQ)}#crm_auto_sync=1&erp_url=${encodeURIComponent(currentErpUrl)}`,
            "_blank"
          );
        }
      } else if (event.data?.type === "CRM_CHECK_COMPETITOR_LINK") {
        const { requestId, payload } = event.data;
        chrome.runtime.sendMessage(
          { action: "INSPECT_COMPETITOR_LINK", payload },
          (response) => {
            const err = chrome.runtime.lastError;
            window.postMessage(
              {
                type: "CRM_COMPETITOR_CHECK_RESULT",
                requestId,
                result: response || {
                  success: false,
                  error: err ? err.message : "Sem resposta da extensão",
                },
              },
              "*"
            );
          }
        );
      }
    });

    return;
  }

  // Detecta plataforma
  const isMercadoLivre = window.location.hostname.includes("mercadolivre.com.br");
  const isShopee = window.location.hostname.includes("shopee.com.br");

  if (!isMercadoLivre && !isShopee) return;

  /**
   * Helper: Limpa e converte strings de moeda brasileira para float (Ex: "R$ 1.250,90" -> 1250.90)
   */
  function parseBrlCurrency(text) {
    if (!text) return 0;
    const clean = text
      .toString()
      .replace(/[^\d.,]/g, "")
      .replace(/\./g, "")
      .replace(",", ".");
    const parsed = parseFloat(clean);
    return isNaN(parsed) ? 0 : parsed;
  }

  /**
   * Helper: Normaliza URLs de imagem e links garantindo protocolo https://
   */
  function normalizeUrl(url) {
    if (!url || typeof url !== "string") return null;
    let trimmed = url.trim();
    if (trimmed.startsWith("//")) return "https:" + trimmed;
    if (trimmed.startsWith("http://")) return trimmed.replace("http://", "https://");
    if (!trimmed.startsWith("https://") && !trimmed.startsWith("data:")) {
      return "https://" + trimmed;
    }
    return trimmed;
  }

  /**
   * Extração via Schema.org LD+JSON com busca profunda recursiva (incluindo @graph e coleções)
   */
  function extractFromJsonLd() {
    try {
      const scripts = document.querySelectorAll('script[type="application/ld+json"]');

      function findProductInObject(obj) {
        if (!obj || typeof obj !== "object") return null;
        if (obj["@type"] === "Product") return obj;

        if (Array.isArray(obj)) {
          for (const item of obj) {
            const found = findProductInObject(item);
            if (found) return found;
          }
        }

        if (obj["@graph"] && Array.isArray(obj["@graph"])) {
          for (const item of obj["@graph"]) {
            const found = findProductInObject(item);
            if (found) return found;
          }
        }

        for (const key of Object.keys(obj)) {
          if (typeof obj[key] === "object" && obj[key] !== null) {
            const found = findProductInObject(obj[key]);
            if (found) return found;
          }
        }

        return null;
      }

      for (const script of scripts) {
        if (!script.textContent) continue;
        try {
          const parsed = JSON.parse(script.textContent);
          const target = findProductInObject(parsed);

          if (target) {
            const offers = Array.isArray(target.offers) ? target.offers[0] : target.offers;
            const price = offers?.price ? parseFloat(offers.price) : 0;
            const seller = offers?.seller?.name || target.brand?.name || null;
            const sku = target.sku || offers?.sku || null;

            return {
              title: target.name || null,
              current_price: price > 0 ? price : null,
              seller_name: seller,
              sku: sku,
              image: target.image
                ? Array.isArray(target.image)
                  ? normalizeUrl(target.image[0])
                  : normalizeUrl(target.image)
                : null,
            };
          }
        } catch {
          // Continua para o próximo script
        }
      }
    } catch (e) {
      console.warn("[ERP Extractor] Falha ao parsear LD+JSON:", e);
    }
    return null;
  }

  /**
   * Tabelas de calibração cronológica Dual-Shard de IDs do Mercado Livre Brasil (MLB)
   * O Mercado Livre Brasil utiliza duas sequências monotônicas paralelas (IDs ímpares e IDs pares).
   */
  const ODD_MLB_ANCHORS = [
    [1000000001, 1520000000],
    [2000000001, 1630000000],
    [3000000001, 1672531200],
    [3500000001, 1704067200],
    [3604088865, 1708614317],
    [3677706001, 1714672144],
    [3775570601, 1720721286],
    [3791988025, 1721905870],
    [3870433327, 1728306310],
    [3878354037, 1729017450],
    [3950553465, 1736687662],
    [4405079191, 1767714028],
    [4473157969, 1770897600],
    [4516465031, 1773081053],
    [4637247523, 1777301270],
    [4680140101, 1778774182],
    [4729260091, 1780401600],
    [4815068677, 1782408395],
    [4907118005, 1784298505],
    [4949688649, 1785118614],
    [5007001935, 1786033623],
    [5049362965, 1786580776],
    [5102291473, 1787268007],
    [5147833041, 1787875766],
    [5180213341, 1788400367],
    [5215384915, 1789056122],
    [5261622325, 1789846455],
    [5281070631, 1790166636],
    [5309734189, 1790683356],
    [5342125297, 1791301373],
    [5371657083, 1791737346],
    [5390836089, 1791979815],
    [5392217295, 1791993935],
    [5425017267, 1792428203],
    [5451861735, 1792759331],
    [5467689883, 1793060428],
    [5481288423, 1793274499],
    [5495858211, 1793552607],
  ];

  const EVEN_MLB_ANCHORS = [
    [4000000000, 1692000000],
    [4057151224, 1695323882],
    [4239931650, 1701085623],
    [4323562446, 1703681117],
    [4440840978, 1707647181],
    [4663801474, 1715198758],
    [5279238968, 1738893724],
    [5302227582, 1740690198],
    [5325009484, 1742573943],
    [5478913174, 1751758357],
    [5803698714, 1760521760],
    [5933540874, 1763057982],
    [6052459348, 1765732276],
    [6168219740, 1768392000],
    [6257283512, 1771354409],
    [6310961644, 1772198879],
    [6662209498, 1776978982],
    [6776418892, 1778775181],
    [6936719092, 1781103327],
    [7032025666, 1782369862],
    [7071688620, 1782920858],
    [7136348316, 1783638496],
    [7259550226, 1785118538],
    [7349483204, 1786059234],
    [7390551330, 1786481774],
    [7400693466, 1786581179],
    [7472416462, 1787271960],
    [7536360518, 1787876196],
    [7585061812, 1788450863],
    [7619525010, 1789056362],
    [7669930830, 1789847705],
    [7721699724, 1790681669],
    [7757951996, 1791302312],
    [7777671248, 1791565814],
    [7790395684, 1791740343],
    [7819244990, 1792079149],
    [7846016296, 1792426830],
    [7862839620, 1792636014],
    [7891206434, 1793059319],
  ];

  function interpolateMlbCreationDate(externalId, thumbnailUrl = null) {
    try {
      const m = String(externalId || "").match(/MLB(?!U)-?(\d{8,12})/i);
      if (m) {
        const num = parseInt(m[1], 10);
        // IDs reais de anúncios MLB possuem 9 ou 10 dígitos (>= 1.000.000.000).
        // IDs de 8 dígitos (ex: MLB19582312) são códigos de produto de catálogo (/p/MLB...).
        if (!isNaN(num) && num >= 1000000000) {
          const anchors = num % 2 === 0 && num >= 4000000000 ? EVEN_MLB_ANCHORS : ODD_MLB_ANCHORS;
          let sec = 0;

          if (num <= anchors[0][0]) {
            const [x0, y0] = anchors[0];
            const [x1, y1] = anchors[1];
            sec = y0 - ((x0 - num) / (x1 - x0)) * (y1 - y0);
          } else if (num >= anchors[anchors.length - 1][0]) {
            const [x0, y0] = anchors[anchors.length - 2];
            const [x1, y1] = anchors[anchors.length - 1];
            sec = y1 + ((num - x1) / (x1 - x0)) * (y1 - y0);
          } else {
            for (let i = 0; i < anchors.length - 1; i++) {
              const [x0, y0] = anchors[i];
              const [x1, y1] = anchors[i + 1];
              if (num >= x0 && num <= x1) {
                sec = y0 + ((num - x0) / (x1 - x0)) * (y1 - y0);
                break;
              }
            }
          }

          const nowSec = Math.floor(Date.now() / 1000);
          const clamped = Math.min(Math.round(sec), nowSec);
          if (clamped > 1200000000) {
            return new Date(clamped * 1000).toISOString();
          }
        }
      }

      // Fallback apenas para itens de catálogo puro (MLBU ou MLB de 8 dígitos) sem ID de anúncio de 10 dígitos
      if (thumbnailUrl) {
        const imgDateMatch = String(thumbnailUrl).match(/_(\d{2})(20\d{2})-/);
        if (imgDateMatch) {
          const month = parseInt(imgDateMatch[1], 10);
          const year = parseInt(imgDateMatch[2], 10);
          if (month >= 1 && month <= 12 && year >= 2015 && year <= 2030) {
            const endOfMonthMs = new Date(Date.UTC(year, month, 0, 12, 0, 0)).getTime();
            const defaultMs = Math.min(endOfMonthMs, Date.now());
            return new Date(defaultMs).toISOString();
          }
        }
      }
    } catch {}
    return null;
  }

  /**
   * Helper: Extrai quantidade estimada de vendas do Mercado Livre
   * IMPORTANTE: Verifica estritamente o subtítulo do anúncio (.ui-pdp-subtitle).
   * Se o subtítulo for apenas "Novo" ou "Usado" (sem "vendido"), retorna 0 imediatamente
   * para NUNCA capturar o total de vendas da loja do vendedor (ex: "+1000 vendas") ou carrosséis.
   */
  function extractMlSalesCount() {
    try {
      // 1. Subtítulo oficial do cabeçalho do anúncio (.ui-pdp-subtitle)
      const subtitleEl =
        document.querySelector(".ui-pdp-header .ui-pdp-subtitle") ||
        document.querySelector(".ui-pdp-subtitle") ||
        document.querySelector(".ui-pdp-header__subtitle") ||
        document.querySelector('[class*="ui-pdp-subtitle"]');

      if (subtitleEl && subtitleEl.innerText) {
        const text = subtitleEl.innerText.trim();
        const match = text.match(/(\+?\d+(?:[\.,]\d+)?)\s*(mil|k)?\s*vendid/i);
        if (match) {
          let num = parseFloat(match[1].replace("+", "").replace(/\./g, "").replace(",", "."));
          if (match[2] && (match[2].toLowerCase().startsWith("mil") || match[2].toLowerCase() === "k")) {
            num = num * 1000;
          }
          if (!isNaN(num) && num >= 0) return Math.round(num);
        }
        // Se o subtítulo existe (ex: "Novo" ou "Usado") e NÃO contém "vendido", o anúncio tem 0 vendas!
        if (/novo|usado|recondicionado/i.test(text)) {
          return 0;
        }
      }

      // 2. Fallback restrito APENAS ao container do cabeçalho do produto (nunca vendedor ou carrossel)
      const headerContainer = document.querySelector(".ui-pdp-header");
      if (headerContainer && headerContainer.innerText) {
        const match = headerContainer.innerText.match(/(\+?\d+(?:[\.,]\d+)?)\s*(mil|k)?\s*vendid/i);
        if (match) {
          let num = parseFloat(match[1].replace("+", "").replace(/\./g, "").replace(",", "."));
          if (match[2] && (match[2].toLowerCase().startsWith("mil") || match[2].toLowerCase() === "k")) {
            num = num * 1000;
          }
          if (!isNaN(num) && num >= 0) return Math.round(num);
        }
      }
    } catch (e) {
      console.warn("[ERP Extractor] Erro ao extrair vendas ML:", e);
    }
    return 0;
  }

  /**
   * Helper: Extrai data de criação do anúncio do Mercado Livre (Multicamada)
   */
  function extractMlCreationDate(externalId = null, thumbnailUrl = null) {
    window.__LAST_ML_DATE_FROM_DOM__ = false;
    try {
      // Camada 1: Informação explícita ou relativa visível no DOM
      // Ex: "Publicado: há 294 dias", tooltip "14/01/2026", "Publicado em 14/01/2026", "Anunciado 14 jan. 2026"
      const bodyText = document.body?.innerText || "";
      const bodyHtml = document.body?.innerHTML || "";

      // 1a. Data explícita próxima de "Publicado" (incluindo tooltips como 14/01/2026)
      const pubTooltipMatch =
        bodyHtml.match(/Publicado[\s\S]{0,350}?(\d{2})\/(\d{2})\/(20\d{2})/i) ||
        bodyText.match(/Publicado\s*(?:em|:)?\s*(\d{2})\/(\d{2})\/(20\d{2})/i);
      if (pubTooltipMatch) {
        const day = parseInt(pubTooltipMatch[1], 10);
        const month = parseInt(pubTooltipMatch[2], 10) - 1;
        const year = parseInt(pubTooltipMatch[3], 10);
        const d = new Date(Date.UTC(year, month, day, 12, 0, 0));
        if (!isNaN(d.getTime())) {
          window.__LAST_ML_DATE_FROM_DOM__ = true;
          return d.toISOString();
        }
      }

      // 1b. Padrão "Anunciado 14 jan. 2026"
      const ptMonths = {
        jan: 0, fev: 1, mar: 2, abr: 3, mai: 4, jun: 5,
        jul: 6, ago: 7, set: 8, out: 9, nov: 10, dez: 11,
      };
      const anunciadoMatch = bodyText.match(
        /Anunciado\s+(?:em\s+)?(\d{1,2})\s+(?:de\s+)?(jan|fev|mar|abr|mai|jun|jul|ago|set|out|nov|dez)[a-z.]*\s+(?:de\s+)?(20\d{2})/i
      );
      if (anunciadoMatch) {
        const day = parseInt(anunciadoMatch[1], 10);
        const mKey = anunciadoMatch[2].toLowerCase().slice(0, 3);
        const year = parseInt(anunciadoMatch[3], 10);
        if (ptMonths[mKey] !== undefined) {
          const d = new Date(Date.UTC(year, ptMonths[mKey], day, 12, 0, 0));
          if (!isNaN(d.getTime())) {
            window.__LAST_ML_DATE_FROM_DOM__ = true;
            return d.toISOString();
          }
        }
      }

      // 1c. Padrão "Publicado: há 294 dias"
      const relDaysMatch = bodyText.match(/Publicado:?\s*h[áa]\s*(\d+)\s*dias?/i);
      if (relDaysMatch) {
        const days = parseInt(relDaysMatch[1], 10);
        if (!isNaN(days) && days >= 0 && days < 5000) {
          window.__LAST_ML_DATE_FROM_DOM__ = true;
          return new Date(Date.now() - days * 86400000).toISOString();
        }
      }
      if (/Publicado:?\s*hoje/i.test(bodyText)) {
        window.__LAST_ML_DATE_FROM_DOM__ = true;
        return new Date().toISOString();
      }
      if (/Publicado:?\s*ontem/i.test(bodyText)) {
        window.__LAST_ML_DATE_FROM_DOM__ = true;
        return new Date(Date.now() - 86400000).toISOString();
      }

      // Camada 2: Scripts JSON embutidos na página (APENAS startTime / start_time do item;
      // NUNCA "date_created" genérico pois reviews e perguntas possuem date_created próprios!)
      const scripts = document.querySelectorAll("script");
      for (const script of scripts) {
        const content = script.textContent;
        if (!content) continue;

        const match =
          content.match(/"startTime"\s*:\s*"([^"]+)"/i) ||
          content.match(/"start_time"\s*:\s*"([^"]+)"/i);

        if (match && match[1]) {
          const d = new Date(match[1]);
          if (!isNaN(d.getTime())) {
            window.__LAST_ML_DATE_FROM_DOM__ = true;
            return d.toISOString();
          }
        }
      }

      // Camada 3: Interpolação Cronológica Dual-Shard do ID MLB
      const interpolated = interpolateMlbCreationDate(externalId, thumbnailUrl);
      if (interpolated) return interpolated;
    } catch (e) {
      console.warn("[ERP Extractor] Erro ao extrair data de criação ML:", e);
    }
    return null;
  }

  /**
   * Refina a localização/seller_id do concorrente na página da loja e só usa Last-Modified da imagem
   * caso o anúncio não possua um ID de anúncio MLB de 9-12 dígitos (ex: página de catálogo MLBU pura).
   * IMPORTANTE: Jamais sobrescreve a data de um ID MLB válido com Last-Modified da foto de capa,
   * pois vendedores frequentemente trocam a foto de capa meses depois de criar o anúncio!
   */
  async function refineMlCreationDateAsync(data) {
    if (!data || data.platform !== "mercadolivre") return data;
    try {
      const targetId = String(data.resolved_item_id || data.external_id || "");
      const hasValidMlbListingId = /^MLB-?\d{9,12}$/i.test(targetId);

      if (!data.listing_created_at && !hasValidMlbListingId) {
        let candidateUrls = [];
        if (Array.isArray(data.pictures)) {
          for (const p of data.pictures) {
            const u = p?.originalUrl || p?.primaryUrl || (typeof p === "string" ? p : null);
            if (u && u.includes("mlstatic.com")) candidateUrls.push(u);
          }
        }
        const fallbackImg =
          data.thumbnail_url ||
          document.querySelector('meta[property="og:image"]')?.getAttribute("content") ||
          document.querySelector(".ui-pdp-gallery__figure img")?.getAttribute("src");
        if (fallbackImg && fallbackImg.includes("mlstatic.com")) {
          candidateUrls.unshift(fallbackImg);
        }

        let bestImgUrl = candidateUrls[0] || null;
        let earliestYm = 999999;
        for (const u of candidateUrls) {
          const ymMatch = String(u).match(/_(\d{2})(20\d{2})-/);
          if (ymMatch) {
            const ymVal = parseInt(ymMatch[2], 10) * 100 + parseInt(ymMatch[1], 10);
            if (ymVal < earliestYm) {
              earliestYm = ymVal;
              bestImgUrl = u;
            }
          }
        }

        if (bestImgUrl && bestImgUrl.includes("mlstatic.com")) {
          const controller = new AbortController();
          const timer = setTimeout(() => controller.abort(), 1400);
          const res = await fetch(bestImgUrl.replace(/^http:\/\//i, "https://"), {
            method: "GET",
            headers: { Range: "bytes=0-1" },
            signal: controller.signal,
          }).catch(() => null);
          clearTimeout(timer);

          const lastMod = res?.headers?.get("last-modified");
          if (lastMod) {
            const imgDate = new Date(lastMod);
            if (
              !isNaN(imgDate.getTime()) &&
              imgDate.getFullYear() >= 2015 &&
              imgDate.getTime() <= Date.now() + 86400000
            ) {
              data.listing_created_at = imgDate.toISOString();
            }
          }
        }
      }

      // Se o seller_id ou a localização do vendedor ainda não foram encontrados na PDP, consulta o link da loja (/pagina/...)
      if ((!data.seller_id || !data.seller_location) && data.seller_store_url && data.seller_store_url.includes("mercadolivre.com.br")) {
        try {
          const locCtrl = new AbortController();
          const locTimer = setTimeout(() => locCtrl.abort(), 1400);
          const storeRes = await fetch(data.seller_store_url, {
            method: "GET",
            credentials: "include",
            signal: locCtrl.signal,
          }).catch(() => null);
          clearTimeout(locTimer);
          if (storeRes && storeRes.ok) {
            const storeHtml = await storeRes.text();
            if (!data.seller_id) {
              const sidMatch =
                storeHtml.match(/"seller_id"\s*:\s*"?(\d{5,15})"?/i) ||
                storeHtml.match(/\\"seller_id\\"\s*:\s*\\"?(\d{5,15})\\"?/i) ||
                storeHtml.match(/"owner_id"\s*:\s*"?(\d{5,15})"?/i) ||
                storeHtml.match(/\\"owner_id\\"\s*:\s*\\"?(\d{5,15})\\"?/i) ||
                storeHtml.match(/_CustId_(\d{5,15})/i);
              if (sidMatch && sidMatch[1]) {
                data.seller_id = sidMatch[1];
              }
            }
            if (!data.seller_location) {
              // NUNCA faz match em "city" genérico pois o cabeçalho do ML traz o CEP do comprador ("Enviar para...")
              const locFromProfile = storeHtml.match(/Localizado\s+em\s+([^<".\n]{3,45})/i)?.[1];
              if (typeof locFromProfile === "string" && locFromProfile.trim()) {
                data.seller_location = locFromProfile.trim();
              }
            }
          }
        } catch {}
      }
    } catch {}
    return data;
  }

  /**
   * Helper: Extrai a localização do vendedor/concorrente no Mercado Livre (Cidade / Estado)
   * IMPORTANTE: Jamais usa regex genérico de "city"/"state" no HTML global, pois o cabeçalho do ML
   * injeta o endereço de destino do próprio comprador logado ("Enviar para Passo Fundo - RS").
   */
  function extractMlSellerLocation(scriptsText = "") {
    try {
      // 1. Containers estritos de informação do vendedor no DOM (.ui-seller-info__status-info)
      const statusBlocks = document.querySelectorAll(
        ".ui-seller-info__status-info, .ui-pdp-seller__status-info, [class*='seller-info__status']"
      );
      for (const block of statusBlocks) {
        const header = block.querySelector(".ui-seller-info__status-info__title, h3, strong")?.innerText?.trim() || "";
        const subtitle = block.querySelector(".ui-seller-info__status-info__subtitle, p, span")?.innerText?.trim() || "";
        if (/localiza[çc][ãa]o/i.test(header) && subtitle) {
          return subtitle;
        }
        const fullText = (block.innerText || "").replace(/\s+/g, " ").trim();
        const locMatch = fullText.match(/Localiza[çc][ãa]o\s*:?\s*(.+)$/i) || fullText.match(/Localizado\s+em\s+(.+)$/i);
        if (locMatch && locMatch[1]) {
          return locMatch[1].trim();
        }
      }

      // 2. JSON estrito de seller_address (endereço do VENDEDOR, nunca buyer/destination)
      if (scriptsText) {
        const addrRegex =
          /"seller_address"\s*:\s*\{[\s\S]{0,600}?"city"\s*:\s*\{\s*(?:"id"\s*:\s*"[^"]*"\s*,\s*)?"name"\s*:\s*"([^"]+)"\s*\}[\s\S]{0,200}?"state"\s*:\s*\{\s*"id"\s*:\s*"(?:BR-)?([A-Z]{2})"\s*,\s*"name"\s*:\s*"([^"]+)"/i;
        const m = scriptsText.match(addrRegex);
        if (m && m[1]) {
          return m[2] ? `${m[1]} - ${m[2]}` : `${m[1]} - ${m[3]}`;
        }
      }

      // 3. Perfil do vendedor no DOM ("Localizado em ...")
      const sellerProfileContainers = document.querySelectorAll(
        ".ui-vpp-seller-profile, .ui-box-component-pdp__seller, [class*='seller-profile']"
      );
      for (const el of sellerProfileContainers) {
        const txt = (el.innerText || "").replace(/\s+/g, " ").trim();
        const m = txt.match(/Localizado\s+em\s+([A-ZÀ-Úa-zà-ú\s]+(?:[,-]\s*[A-ZÀ-Úa-zà-ú]{2,20})?)/i);
        if (m && m[1] && m[1].length >= 3 && m[1].length <= 45) {
          return m[1].trim();
        }
      }
    } catch {}
    return null;
  }

  /**
   * Helper: Extrai o peso faturável do produto (em gramas) da Ficha Técnica do DOM, Descrição ou Título
   */
  function extractMlProductWeightGrams(title = "", scriptsText = "") {
    try {
      // 1. Ficha Técnica (Tabelas Andes e listas de especificações)
      const rows = document.querySelectorAll(
        ".andes-table tr, .ui-vpp-striped-specs__table tr, .ui-pdp-specs__table tr, [class*='specs'] tr"
      );
      for (const row of rows) {
        const th = (row.querySelector("th, td:first-child")?.innerText || "").trim().toLowerCase();
        const td = (row.querySelector("td:last-child, td:nth-child(2)")?.innerText || "").trim().toLowerCase();
        if (th && td && /(?:^|\s)peso(?:\s|$|bruto|l[íi]quido|do produto|aproximado)/i.test(th)) {
          const kgMatch = td.match(/(\d+(?:[.,]\d+)?)\s*(?:kg|quilos?)\b/i);
          if (kgMatch) {
            const val = parseFloat(kgMatch[1].replace(",", "."));
            if (val > 0 && val <= 150) return Math.round(val * 1000);
          }
          const gMatch = td.match(/(\d+(?:[.,]\d+)?)\s*(?:g|gr|gramas?)\b/i);
          if (gMatch) {
            const val = parseFloat(gMatch[1].replace(",", "."));
            if (val >= 10 && val <= 150000) return Math.round(val);
          }
        }
      }

      // 2. Atributos estruturados em JSON nos scripts da página (id: "WEIGHT" ou "PACKAGE_WEIGHT")
      if (scriptsText) {
        const attrWeightMatch =
          scriptsText.match(/"id"\s*:\s*"(?:PACKAGE_)?WEIGHT"[\s\S]{0,250}?"value_name"\s*:\s*"(\d+(?:[.,]\d+)?)\s*(kg|g)"/i) ||
          scriptsText.match(/"name"\s*:\s*"Peso[^"]*"[\s\S]{0,200}?"value_name"\s*:\s*"(\d+(?:[.,]\d+)?)\s*(kg|g)"/i);
        if (attrWeightMatch) {
          const num = parseFloat(attrWeightMatch[1].replace(",", "."));
          const unit = attrWeightMatch[2].toLowerCase();
          if (num > 0) {
            const grams = unit === "kg" ? Math.round(num * 1000) : Math.round(num);
            if (grams >= 10 && grams <= 150000) return grams;
          }
        }
      }

      // 3. Descrição do anúncio ("Peso: 3,8 kg" / "Peso aprox.: 3.5kg")
      const descEl = document.querySelector(".ui-pdp-description__content, [data-testid='content']");
      if (descEl && descEl.innerText) {
        const descText = descEl.innerText;
        const descWeightMatch = descText.match(
          /peso(?:\s+aprox(?:imado)?\.?|\s+l[íi]quido|\s+bruto|\s+do\s+produto)?\s*[:=-]?\s*(\d+(?:[.,]\d+)?)\s*(kg|quilos?|g|gr|gramas?)\b/i
        );
        if (descWeightMatch) {
          const num = parseFloat(descWeightMatch[1].replace(",", "."));
          const unit = descWeightMatch[2].toLowerCase();
          if (num > 0) {
            const grams = unit.startsWith("k") || unit.startsWith("q") ? Math.round(num * 1000) : Math.round(num);
            if (grams >= 20 && grams <= 150000) return grams;
          }
        }
      }

      // 4. Inferência inteligente pelo título (ex: "2000va", "3kg", "500g", "bateria", etc.)
      const t = (title || "").toLowerCase();
      if (t) {
        const kgTitle = t.match(/\b(\d+(?:[.,]\d+)?)\s*(?:kg|quilos?)\b/i);
        if (kgTitle) {
          const kg = parseFloat(kgTitle[1].replace(",", "."));
          if (kg > 0 && kg <= 100) return Math.round(kg * 1000);
        }
        const gTitle = t.match(/\b(\d{2,5})\s*(?:g|gr|gramas)\b/i);
        if (gTitle) {
          const g = parseInt(gTitle[1], 10);
          if (g >= 50 && g <= 50000) return g;
        }
        if (/\b(?:transformador|autotransformador|trafo)\b/i.test(t)) {
          const vaMatch = t.match(/\b(\d{3,5})\s*(?:va|w|watts)\b/i);
          if (vaMatch) {
            const va = parseInt(vaMatch[1], 10);
            if (va >= 5000) return 7500;
            if (va >= 3000) return 5200;
            if (va >= 2000) return 3800;
            if (va >= 1500) return 2900;
            if (va >= 1000) return 2250;
            if (va >= 750) return 1700;
            if (va >= 500) return 1250;
            return 850;
          }
          return 2500;
        }
        if (/bateria\s+automotiva|bateria\s+60ah|bateria\s+moura/i.test(t)) return 11500;
        if (/kit\s+motor|motor\s+deslizante|motor\s+port[ãa]o/i.test(t)) return 5500;
        if (/pneu\s+\d{3}|roda\s+aro/i.test(t)) return 8500;
      }
    } catch {}
    return 250; // Padrão leve (< 300g)
  }

  /**
   * Calcula o custo de frete Mercado Envios (50% desconto Líder/Verde) considerando Preço + Faixa de Peso
   */
  function estimateMlShippingByPriceAndWeight(price, weightGrams = 250) {
    if (!price || price < 79) return 0;

    let tier = 0; // R$ 79 a R$ 99,99
    if (price >= 200) tier = 4;
    else if (price >= 150) tier = 3;
    else if (price >= 120) tier = 2;
    else if (price >= 100) tier = 1;

    const w = weightGrams > 0 ? weightGrams : 250;
    if (w <= 300) return [13.65, 16.85, 18.65, 20.45, 22.45][tier];
    if (w <= 500) return [14.45, 17.85, 19.85, 21.45, 23.45][tier];
    if (w <= 1000) return [15.45, 18.95, 20.95, 22.95, 24.95][tier];
    if (w <= 2000) return [16.95, 19.95, 22.45, 24.45, 26.95][tier];
    if (w <= 3000) return [18.45, 21.45, 23.95, 26.45, 28.95][tier];
    if (w <= 5000) return [19.95, 22.85, 25.45, 28.45, 31.45][tier];
    if (w <= 9000) return [26.95, 30.95, 34.45, 38.45, 42.95][tier];
    if (w <= 13000) return [36.95, 41.95, 46.95, 51.95, 56.95][tier];
    return [44.95, 51.95, 57.95, 63.95, 69.95][tier];
  }

  /**
   * Helper: Extrai quantidade estimada de vendas da Shopee
   */
  function extractShopeeSalesCount() {
    try {
      const elements = document.querySelectorAll("div, span");
      for (const el of elements) {
        if (el.children.length === 0 && /vendid/i.test(el.innerText || "")) {
          const match = el.innerText.match(/(\d+(?:[\.,]\d+)?)\s*(mil|k)?\s*vendid/i);
          if (match) {
            let num = parseFloat(match[1].replace(/\./g, "").replace(",", "."));
            if (match[2] && (match[2].toLowerCase().startsWith("mil") || match[2].toLowerCase() === "k")) {
              num = num * 1000;
            }
            if (!isNaN(num) && num >= 0) return Math.round(num);
          }
        }
      }

      const scripts = document.querySelectorAll("script");
      for (const script of scripts) {
        const content = script.textContent;
        if (content && content.includes("historical_sold")) {
          const match = content.match(/"historical_sold"\s*:\s*(\d+)/);
          if (match) {
            const count = parseInt(match[1], 10);
            if (!isNaN(count)) return count;
          }
        }
      }
    } catch (e) {
      console.warn("[ERP Extractor] Erro ao extrair vendas Shopee:", e);
    }
    return 0;
  }

  /**
   * Helper: Extrai data de criação da Shopee (ctime / create_time)
   */
  function extractShopeeCreationDate() {
    try {
      const scripts = document.querySelectorAll("script");
      for (const script of scripts) {
        const content = script.textContent;
        if (content && (content.includes('"ctime"') || content.includes('"create_time"'))) {
          const match = content.match(/"ctime"\s*:\s*(\d+)/) || content.match(/"create_time"\s*:\s*(\d+)/);
          if (match) {
            let ts = parseInt(match[1], 10);
            if (ts < 1e11) ts = ts * 1000;
            const d = new Date(ts);
            if (!isNaN(d.getTime())) return d.toISOString();
          }
        }
      }
    } catch (e) {
      console.warn("[ERP Extractor] Erro ao extrair data criação Shopee:", e);
    }
    return null;
  }

  /**
   * Extração Completa de Fotos do Anúncio (Mercado Livre e Shopee)
   * Coleta da Galeria DOM, LD+JSON e Scripts Preload, normalizando para URLs em resolução máxima.
   */
  function extractAllListingImages() {
    const images = [];
    const seenIds = new Set();
    const seenUrls = new Set();

    function addImage(rawUrl) {
      if (!rawUrl || typeof rawUrl !== "string") return;
      let url = rawUrl.trim();
      if (url.startsWith("//")) url = "https:" + url;
      if (url.startsWith("http://")) url = url.replace("http://", "https://");
      if (!url.startsWith("https://")) return;

      // Filtra sprites, ícones de UI e pixels de rastreamento
      if (
        url.includes("pixel.gif") ||
        url.includes("clear.png") ||
        url.includes("sprite") ||
        url.includes("ui-pdp-icon") ||
        url.includes("pt_logo_large_plus") ||
        url.includes("logo_mercadolivre") ||
        url.includes("feedback")
      ) {
        return;
      }

      if (isMercadoLivre) {
        // Padrão de imagens de produtos no mlstatic:
        // D_NQ_NP_2X_716942-MLB5147833041_092022-F.webp
        // D_NQ_NP_716942-MLB5147833041_092022-O.webp
        // D_716942-MLB5147833041_092022-O.jpg
        const mlMatch = url.match(
          /(?:D_NQ_NP_(?:2X_)?|D_)([0-9]+-[A-Za-z0-9]+_[0-9]+|[0-9]+-MLA[0-9]+_[0-9]+|[0-9]+-[A-Z]+[0-9]+_[0-9]+)/i
        );
        if (mlMatch) {
          const photoId = mlMatch[1];
          if (seenIds.has(photoId)) return;
          seenIds.add(photoId);

          // Candidatos de altíssima resolução para Mercado Livre:
          // 1) 2X Zoom (-F) - Maior resolução possível gerada pelo ML (até 1920px)
          // 2) 2X Original (-O) - Resolução original do upload em 2X
          // 3) Standard Original (-O)
          // 4) JPG direto (-O.jpg)
          const highResUrl = `https://http2.mlstatic.com/D_NQ_NP_2X_${photoId}-F.webp`;
          const fallback2x = `https://http2.mlstatic.com/D_NQ_NP_2X_${photoId}-O.webp`;
          const fallbackStd = `https://http2.mlstatic.com/D_NQ_NP_${photoId}-O.webp`;
          const fallbackJpg = `https://http2.mlstatic.com/D_NQ_NP_2X_${photoId}-O.jpg`;
          images.push({
            id: photoId,
            primaryUrl: highResUrl,
            fallbacks: [fallback2x, fallbackStd, fallbackJpg, url],
            originalUrl: url,
          });
          return;
        }
      } else if (isShopee) {
        // Padrão de imagens Shopee (susercontent.com e shopee.com.br)
        if (url.includes("susercontent.com/file/") || url.includes("shopee.com.br/file/")) {
          const parts = url.split("/file/");
          if (parts.length > 1) {
            let hash = parts[1].split(/[?#@]/)[0];
            hash = hash.replace(/_tn$|_xxhdpi$/, "").replace(/\.(webp|jpg|jpeg|png)$/, "");
            if (hash && hash.length >= 10) {
              if (seenIds.has(hash)) return;
              seenIds.add(hash);

              // URL original descompactada da CDN Shopee (resolução nativa do upload)
              const highResUrl = `https://down-br.img.susercontent.com/file/${hash}`;
              images.push({
                id: hash,
                primaryUrl: highResUrl,
                fallbacks: [`https://cf.shopee.com.br/file/${hash}`, url],
                originalUrl: url,
              });
              return;
            }
          }
        }
      }

      if (!seenUrls.has(url)) {
        seenUrls.add(url);
        images.push({
          id: `img_${images.length + 1}`,
          primaryUrl: url,
          fallbacks: [],
          originalUrl: url,
        });
      }
    }

    // 1. Coleta de Scripts / Preloaded State
    try {
      const scripts = document.querySelectorAll("script");
      for (const script of scripts) {
        const content = script.textContent || "";
        if (!content) continue;

        if (isMercadoLivre && (content.includes('"pictures"') || content.includes("__PRELOADED_STATE__"))) {
          const picRegex = /"pictures"\s*:\s*(\[[^\]]+\])/g;
          let match;
          while ((match = picRegex.exec(content)) !== null) {
            try {
              const parsed = JSON.parse(match[1]);
              if (Array.isArray(parsed)) {
                for (const p of parsed) {
                  if (p.url) addImage(p.url);
                  if (p.secure_url) addImage(p.secure_url);
                  if (p.id) addImage(`https://http2.mlstatic.com/D_NQ_NP_2X_${p.id}-F.webp`);
                }
              }
            } catch {}
          }
          const mlMatches = content.match(/https:\/\/http2\.mlstatic\.com\/D_NQ_NP_[^"'\s\)\\,]+/g);
          if (mlMatches) {
            for (const u of mlMatches) addImage(u);
          }
        }

        if (isShopee && (content.includes('"images"') || content.includes('"image"'))) {
          const shopeeMatches = content.match(/"(?:images|image)"\s*:\s*(\[[^\]]+\]|"[a-zA-Z0-9_-]+")/g);
          if (shopeeMatches) {
            for (const sm of shopeeMatches) {
              const valMatch = sm.match(/:\s*(.*)/);
              if (valMatch) {
                try {
                  const val = JSON.parse(valMatch[1]);
                  if (Array.isArray(val)) {
                    for (const h of val) {
                      if (typeof h === "string") {
                        if (h.startsWith("http")) addImage(h);
                        else addImage(`https://down-br.img.susercontent.com/file/${h}`);
                      }
                    }
                  } else if (typeof val === "string") {
                    if (val.startsWith("http")) addImage(val);
                    else addImage(`https://down-br.img.susercontent.com/file/${val}`);
                  }
                } catch {}
              }
            }
          }
        }
      }
    } catch {}

    // 2. Coleta de LD+JSON
    try {
      const jsonLd = extractFromJsonLd();
      if (jsonLd?.image) {
        if (Array.isArray(jsonLd.image)) {
          for (const u of jsonLd.image) addImage(u);
        } else {
          addImage(jsonLd.image);
        }
      }
    } catch {}

    // 3. Coleta da Galeria DOM
    if (isMercadoLivre) {
      const zoomEls = document.querySelectorAll(
        ".ui-pdp-gallery img[data-zoom], img.ui-pdp-image[data-zoom], img[data-zoom]"
      );
      zoomEls.forEach((el) => {
        addImage(el.getAttribute("data-zoom"));
        addImage(el.getAttribute("data-src"));
        addImage(el.getAttribute("src"));
      });

      const galleryImgs = document.querySelectorAll(
        ".ui-pdp-gallery figure img, .ui-pdp-gallery__figure img, span.ui-pdp-gallery__wrapper img, label.ui-pdp-gallery__label img, .ui-pdp-gallery__thumbnail img, img.ui-pdp-image"
      );
      galleryImgs.forEach((el) => {
        addImage(el.getAttribute("data-zoom"));
        addImage(el.getAttribute("data-src"));
        addImage(el.getAttribute("src"));
      });
    } else if (isShopee) {
      const shopeeImgs = document.querySelectorAll(
        'picture img, div[class*="product-briefing"] img, div[class*="image-carousel"] img, div[class*="carousel"] img'
      );
      shopeeImgs.forEach((el) => {
        addImage(el.getAttribute("src"));
        addImage(el.getAttribute("data-src"));
      });

      const bgElements = document.querySelectorAll(
        'div[style*="down-br.img.susercontent.com"], div[style*="susercontent.com"], div[style*="cf.shopee.com.br"]'
      );
      bgElements.forEach((el) => {
        const style = el.getAttribute("style") || "";
        const bgMatch = style.match(/url\(["']?([^"')]+)["']?\)/);
        if (bgMatch) addImage(bgMatch[1]);
      });
    }

    // 4. Fallback com OpenGraph se nenhuma foto detectada
    if (images.length === 0) {
      const ogImg = document.querySelector('meta[property="og:image"]')?.getAttribute("content");
      if (ogImg) addImage(ogImg);
    }

    return images;
  }

  /**
   * Extração Específica: MERCADO LIVRE (Multicamada)
   */
  function extractMercadoLivre() {
    const jsonLd = extractFromJsonLd();

    // 1. External ID (MLB...)
    let externalId = "";
    const canonical =
      document.querySelector('link[rel="canonical"]')?.getAttribute("href") ||
      window.location.href;

    const mlbMatch =
      canonical.match(/MLB-?(\d+)/i) ||
      window.location.pathname.match(/MLB-?(\d+)/i) ||
      window.location.href.match(/MLB-?(\d+)/i);

    if (mlbMatch) {
      externalId = `MLB${mlbMatch[1]}`;
    } else {
      const inputItemId =
        document.querySelector('input[name="item_id"]')?.value ||
        document.querySelector('[data-item-id]')?.getAttribute("data-item-id");
      externalId = inputItemId || "MLB-" + Math.floor(Date.now() / 1000);
    }

    // 2. Título do Anúncio
    let title = "";
    const titleEl =
      document.querySelector(".ui-pdp-title") ||
      document.querySelector("h1.ui-pdp-title") ||
      document.querySelector(".ui-pdp-header__title-container h1") ||
      document.querySelector("h1.andes-typography--title") ||
      document.querySelector("h1");

    if (titleEl && titleEl.innerText.trim()) {
      title = titleEl.innerText.trim();
    } else if (jsonLd?.title) {
      title = jsonLd.title.trim();
    } else {
      const ogTitle = document.querySelector('meta[property="og:title"]')?.getAttribute("content");
      title = ogTitle || document.title.replace(/\|.*$/g, "").replace(/- Mercado Livre.*$/g, "").trim();
    }

    // 3. Preço Atual (Multicamada de Alta Precisão)
    let currentPrice = 0;

    // Camada A: Meta Tags Microdata e OpenGraph (Mais estáveis que classes CSS mutáveis)
    const metaPrice =
      document.querySelector('meta[itemprop="price"]')?.getAttribute("content") ||
      document.querySelector('meta[property="og:price:amount"]')?.getAttribute("content") ||
      document.querySelector('meta[property="product:price:amount"]')?.getAttribute("content");

    if (metaPrice) {
      const p = parseFloat(metaPrice.replace(",", "."));
      if (!isNaN(p) && p > 0) {
        currentPrice = p;
      }
    }

    // Camada B: Seletores do DOM Mercado Livre (Páginas PDP Clássicas e Catálogo)
    if (!currentPrice) {
      // Prioridade: container da segunda linha ou container principal do preço
      const priceContainer =
        document.querySelector(".ui-pdp-price__second-line") ||
        document.querySelector(".ui-pdp-price__main-container") ||
        document.querySelector(".ui-pdp-price:not(.ui-pdp-price__original-value)") ||
        document.querySelector('[data-testid="price-part"]') ||
        document.querySelector(".andes-money-amount--cents-superscript:not(.ui-pdp-price__original-value)");

      if (priceContainer) {
        const fraction =
          priceContainer.querySelector(".andes-money-amount__fraction")?.innerText?.trim() || "";
        const cents =
          priceContainer.querySelector(".andes-money-amount__cents")?.innerText?.trim() || "00";
        if (fraction) {
          currentPrice = parseBrlCurrency(`${fraction},${cents}`);
        }
      }
    }

    // Camada C: JSON-LD Structured Data
    if (!currentPrice && jsonLd?.current_price) {
      currentPrice = jsonLd.current_price;
    }

    // Camada D: Fallback inteligente em qualquer .andes-money-amount que não seja parcelamento
    if (!currentPrice) {
      const allAmounts = document.querySelectorAll(".ui-pdp-price .andes-money-amount");
      for (const amountEl of allAmounts) {
        if (amountEl.closest(".ui-pdp-price__subtitles") || amountEl.closest(".ui-pdp-installments")) {
          continue;
        }
        const fraction = amountEl.querySelector(".andes-money-amount__fraction")?.innerText?.trim();
        const cents = amountEl.querySelector(".andes-money-amount__cents")?.innerText?.trim() || "00";
        if (fraction) {
          const val = parseBrlCurrency(`${fraction},${cents}`);
          if (val > 0) {
            currentPrice = val;
            break;
          }
        }
      }
    }

    // 4. Preço Original (riscado / de promoção)
    let originalPrice = null;
    const originalContainer =
      document.querySelector(".ui-pdp-price__original-value") ||
      document.querySelector(".ui-pdp-price__subtitles s") ||
      document.querySelector("s.andes-money-amount");

    if (originalContainer) {
      const fraction = originalContainer.querySelector(".andes-money-amount__fraction")?.innerText?.trim() || "";
      const cents = originalContainer.querySelector(".andes-money-amount__cents")?.innerText?.trim() || "00";
      if (fraction) {
        const val = parseBrlCurrency(`${fraction},${cents}`);
        if (val > currentPrice) originalPrice = val;
      }
    }

    // 5. Vendedor e Reputação
    let sellerName = jsonLd?.seller_name || "";
    let sellerStoreUrl = null;
    let sellerId = null;

    const sellerLink =
      document.querySelector(".ui-pdp-seller__link-trigger") ||
      document.querySelector(".ui-seller-info a") ||
      document.querySelector(".ui-seller-info__status-info .ui-seller-info__title") ||
      document.querySelector(".ui-seller-data-header__title") ||
      document.querySelector('a[href*="/perfil/"]') ||
      document.querySelector('a[href*="/pagina/"]') ||
      document.querySelector('a[href*="/loja/"]') ||
      document.querySelector('a[href*="_CustId_"]');

    if (sellerLink && sellerLink.innerText.trim()) {
      sellerName = sellerLink.innerText.trim();
    }

    if (sellerLink && (sellerLink.href || sellerLink.getAttribute("href"))) {
      const rawHref = sellerLink.href || sellerLink.getAttribute("href");
      if (rawHref && !rawHref.startsWith("javascript:")) {
        sellerStoreUrl = rawHref.split("?")[0];
        const matchCust = rawHref.match(/_CustId_(\d+)/i);
        if (matchCust) sellerId = matchCust[1];
      }
    }

    if (!sellerId) {
      const htmlScripts = document.documentElement.innerHTML || "";
      const sidMatch =
        htmlScripts.match(/"seller_id"\s*:\s*"?(\d{5,15})"?/i) ||
        htmlScripts.match(/\\"seller_id\\"\s*:\s*\\"?(\d{5,15})\\"?/i) ||
        htmlScripts.match(/"sellerId"\s*:\s*"?(\d{5,15})"?/i) ||
        htmlScripts.match(/_CustId_(\d{5,15})/i);
      if (sidMatch && sidMatch[1]) {
        sellerId = sidMatch[1];
      }
    }

    if (!sellerName) {
      // Procura por "Vendido por"
      const allSpans = document.querySelectorAll("span, p");
      for (const el of allSpans) {
        if (el.innerText && el.innerText.startsWith("Vendido por")) {
          const nextName = el.innerText.replace("Vendido por", "").trim();
          if (nextName) {
            sellerName = nextName;
            break;
          }
        }
      }
    }

    if (!sellerName) {
      sellerName = "Vendedor Mercado Livre";
    } else {
      sellerName = sellerName.replace(/^(Vendido\s+por|Loja:?)\s+/i, "").replace(/\s+/g, " ").trim();
    }

    let sellerReputation = "comum";
    const repText = document.body.innerText.toLowerCase();
    if (repText.includes("mercadolíder platinum") || repText.includes("mercado lider platinum")) {
      sellerReputation = "platinum";
    } else if (repText.includes("mercadolíder gold") || repText.includes("mercado lider gold")) {
      sellerReputation = "gold";
    } else if (repText.includes("loja oficial") || document.querySelector(".ui-pdp-seller__official-store-badge")) {
      sellerReputation = "oficial";
    }

    // 6. Logística e Frete
    let shippingType = "padrao";
    const bodyHtml = document.documentElement.innerHTML;
    if (
      document.querySelector(".ui-pdp-media--full") ||
      bodyHtml.includes("ui-pdp-icon--full") ||
      bodyHtml.includes("Enviado pelo FULL") ||
      bodyHtml.includes("icon-shipping-full")
    ) {
      shippingType = "ml_full";
    } else if (
      bodyHtml.includes("Chegará hoje") ||
      bodyHtml.includes("Chegará amanhã") ||
      bodyHtml.includes("Flex")
    ) {
      shippingType = "ml_flex";
    } else if (bodyHtml.includes("Coleta") || bodyHtml.includes("coleta")) {
      shippingType = "ml_coleta";
    }

    // 7. Selo de Promoção
    let promoBadge = null;
    const promoEl =
      document.querySelector(".ui-pdp-promotions-pill") ||
      document.querySelector(".andes-money-amount__discount");

    if (promoEl && promoEl.innerText.trim()) {
      const cleanPromo = promoEl.innerText.replace(/\s+/g, " ").trim();
      if (!/^\d+x\s*R\$/i.test(cleanPromo) && !/sem\s+juros/i.test(cleanPromo)) {
        promoBadge = cleanPromo.slice(0, 40);
      }
    } else if (bodyHtml.includes("OFERTA DO DIA")) {
      promoBadge = "Oferta do Dia";
    } else if (bodyHtml.includes("RELÂMPAGO") || bodyHtml.includes("Relâmpago")) {
      promoBadge = "Oferta Relâmpago";
    }

    // 8. Thumbnail (Garante protocolo e resolução)
    let thumbnailUrl = null;
    const ogImg = document.querySelector('meta[property="og:image"]')?.getAttribute("content");
    if (ogImg) {
      thumbnailUrl = normalizeUrl(ogImg);
    }

    if (!thumbnailUrl) {
      const imageEl =
        document.querySelector(".ui-pdp-gallery__figure img") ||
        document.querySelector(".ui-pdp-image") ||
        document.querySelector(".ui-pdp-gallery img");
      const src = imageEl?.getAttribute("src") || imageEl?.getAttribute("data-src");
      thumbnailUrl = normalizeUrl(src) || jsonLd?.image || null;
    }

    // 9. Permalink canônico
    let permalink = canonical.split("?")[0];
    permalink = normalizeUrl(permalink) || window.location.href.split("?")[0];

    // 10. Identifica item_id real mesmo em páginas de catálogo (/p/MLB...) antes de calcular a data
    const scriptsText = bodyHtml;
    let resolvedItemId = externalId;
    const urlItemMatch =
      window.location.href.match(/item_id[:=](MLB-?\d{9,12})/i) ||
      window.location.href.match(/[?&]wid=(MLB-?\d{9,12})/i) ||
      scriptsText.match(/"item_id"\s*:\s*"(MLB\d{9,12})"/i);
    if (urlItemMatch && urlItemMatch[1]) {
      resolvedItemId = urlItemMatch[1].replace("-", "").toUpperCase();
    }

    // 11. Vendas e Data de Criação
    const salesCount = extractMlSalesCount();
    const creationDate = extractMlCreationDate(resolvedItemId || externalId, thumbnailUrl);

    // 12. Tipo de Anúncio (Clássico vs Premium), Categoria, Tarifa ML e Frete
    let listingType = "gold_special"; // Clássico por padrão
    const scriptListingTypeMatch = scriptsText.match(/"listing_type_id"\s*:\s*"(gold_pro|gold_special)"/i);
    if (scriptListingTypeMatch) {
      listingType = scriptListingTypeMatch[1].toLowerCase();
    } else {
      const installEl =
        document.querySelector(".ui-pdp-price__subtitles") ||
        document.querySelector(".ui-pdp-installments") ||
        document.querySelector(".ui-pdp-price");
      const installText = installEl?.innerText || "";
      if (/sem\s+juros/i.test(installText) && !/cart[ãa]o\s+mercado\s+pago/i.test(installText)) {
        listingType = "gold_pro"; // Premium (parcelamento sem juros)
      }
    }

    let categoryId = "";
    const catMatch =
      scriptsText.match(/"category_id"\s*:\s*"(MLB\d+)"/i) ||
      scriptsText.match(/"categoryId"\s*:\s*"(MLB\d+)"/i);
    if (catMatch) {
      categoryId = catMatch[1];
    }

    const breadcrumbEls = document.querySelectorAll(".andes-breadcrumb__item, .andes-breadcrumb a");
    const breadcrumb = Array.from(breadcrumbEls)
      .map((el) => (el.innerText || "").trim())
      .filter(Boolean)
      .join(" > ");

    const isPremium = listingType === "gold_pro";
    let saleFeePct = isPremium ? 16.5 : 11.5;
    const fixedFee =
      currentPrice > 0 && currentPrice < 12.5
        ? currentPrice / 2
        : currentPrice < 29
        ? 6.25
        : currentPrice < 50
        ? 6.5
        : currentPrice < 79
        ? 6.75
        : 0;
    let saleFeeAmount =
      currentPrice > 0 ? Number(((currentPrice * saleFeePct) / 100 + fixedFee).toFixed(2)) : 0;

    const sellerLocation = extractMlSellerLocation(scriptsText);
    const weightGrams = extractMlProductWeightGrams(title, scriptsText);
    let shippingCost = estimateMlShippingByPriceAndWeight(currentPrice, weightGrams);

    // Se houver informação explícita de Tarifa/Frete já renderizada no DOM, aproveita os valores exatos
    let feeFromDom = false;
    let shippingFromDom = false;
    const pageBodyText = document.body?.innerText || "";
    const domTarifaMatch = pageBodyText.match(/Tarifa:\s*R\$\s*([\d.,]+)/i);
    const domFreteMatch = pageBodyText.match(/Frete:\s*R\$\s*([\d.,]+)/i);
    if (domTarifaMatch) {
      const parsedT = parseBrlCurrency(domTarifaMatch[1]);
      if (parsedT > 0 && parsedT < currentPrice) {
        saleFeeAmount = parsedT;
        saleFeePct = Number(((saleFeeAmount / currentPrice) * 100).toFixed(1));
        feeFromDom = true;
      }
    }
    if (domFreteMatch) {
      const parsedF = parseBrlCurrency(domFreteMatch[1]);
      if (parsedF > 0 && parsedF < currentPrice) {
        shippingCost = parsedF;
        shippingFromDom = true;
      }
    }

    const netReceivable =
      currentPrice > 0 ? Number(Math.max(0, currentPrice - saleFeeAmount - shippingCost).toFixed(2)) : 0;

    return {
      platform: "mercadolivre",
      external_id: externalId,
      resolved_item_id: resolvedItemId,
      title,
      current_price: currentPrice,
      original_price: originalPrice,
      seller_name: sellerName,
      seller_location: sellerLocation,
      seller_reputation: sellerReputation,
      seller_store_url: sellerStoreUrl,
      seller_id: sellerId,
      shipping_type: shippingType,
      promo_badge: promoBadge,
      permalink,
      thumbnail_url: thumbnailUrl,
      pictures: extractAllListingImages(),
      sales_count_approx: salesCount,
      listing_created_at: creationDate,
      date_from_dom: Boolean(window.__LAST_ML_DATE_FROM_DOM__),
      listing_type: listingType,
      listing_type_label: isPremium ? "Premium" : "Clássico",
      category_id: categoryId || null,
      breadcrumb: breadcrumb || null,
      weight_grams: weightGrams,
      sale_fee_amount: saleFeeAmount,
      sale_fee_pct: saleFeePct,
      shipping_cost: shippingCost,
      fee_from_dom: feeFromDom,
      shipping_from_dom: shippingFromDom,
      net_receivable: netReceivable,
      rating: 4.8,
    };
  }

  /**
   * Extração Específica: SHOPEE
   */
  function extractShopee() {
    const jsonLd = extractFromJsonLd();

    // 1. External ID
    let externalId = "";
    const urlParts =
      window.location.pathname.split("-i.")[1] ||
      window.location.pathname.split("/product/")[1];
    if (urlParts) {
      const ids = urlParts.replace(/\//g, "").split(".");
      if (ids.length >= 2) {
        externalId = `SHP_${ids[0]}_${ids[1]}`;
      } else {
        externalId = `SHP_${urlParts}`;
      }
    } else {
      externalId = "SHP_" + Math.floor(Date.now() / 1000);
    }

    // 2. Título
    let title = jsonLd?.title || "";
    if (!title) {
      const titleEl =
        document.querySelector("h1") ||
        document.querySelector(".vKitProductDetails_title") ||
        document.querySelector(".attM6q");
      title = titleEl?.innerText?.trim() || document.title;
    }

    // 3. Preço
    let currentPrice = 0;
    const priceEl =
      document.querySelector(".G27akf") ||
      document.querySelector(".pmmxKx") ||
      document.querySelector(".IZexXJ") ||
      document.querySelector('div[class*="price"]');
    if (priceEl) {
      currentPrice = parseBrlCurrency(priceEl.innerText);
    }
    if (!currentPrice && jsonLd?.current_price) {
      currentPrice = jsonLd.current_price;
    }

    // 4. Preço Original
    let originalPrice = null;
    const origEl = document.querySelector(".v97Q2Z") || document.querySelector(".X9Vb1P");
    if (origEl) {
      const orig = parseBrlCurrency(origEl.innerText);
      if (orig > currentPrice) originalPrice = orig;
    }

    // 5. Vendedor e Reputação
    let sellerName = jsonLd?.seller_name || "Vendedor Shopee";
    const shopEl =
      document.querySelector(".V5Wf0t") ||
      document.querySelector("._1wPq_F") ||
      document.querySelector('div[class*="shop-name"]');
    if (shopEl?.innerText?.trim()) {
      sellerName = shopEl.innerText.trim();
    }

    let sellerReputation = "indicado";
    const bodyText = document.body.innerText;
    if (bodyText.includes("Shopee Mall") || document.querySelector('img[alt*="Shopee Mall"]')) {
      sellerReputation = "oficial";
    } else if (bodyText.includes("Indicado") || document.querySelector('div[class*="preferred-badge"]')) {
      sellerReputation = "indicado";
    }

    // 6. Logística
    let shippingType = "shopee_padrao";
    if (bodyText.includes("Shopee Xpress") || bodyText.includes("SPX Express")) {
      shippingType = "shopee_xpress";
    } else if (bodyText.includes("Frete grátis com cupom") || bodyText.includes("Frete Grátis")) {
      shippingType = "shopee_frete_gratis";
    }

    // 7. Promoções
    let promoBadge = null;
    if (bodyText.includes("Oferta Relâmpago") || bodyText.includes("Flash Sale")) {
      promoBadge = "Oferta Relâmpago";
    } else if (bodyText.includes("Leve Mais por Menos")) {
      promoBadge = "Combo Promocional";
    }

    // 8. Thumbnail
    const imgEl =
      document.querySelector("picture img") ||
      document.querySelector('div[class*="product-briefing"] img');
    const thumbnailUrl = normalizeUrl(imgEl?.src) || jsonLd?.image || null;

    // 9. Vendas e Data de Criação
    const salesCount = extractShopeeSalesCount();
    const creationDate = extractShopeeCreationDate();

    // 10. Tarifa e Frete Shopee (20% Programa Frete Grátis + R$ 4,00 fixo)
    const shopeePct = 20;
    const shopeeFixed = currentPrice >= 8 ? 4.0 : Number((currentPrice * 0.5).toFixed(2));
    const saleFeeAmount = currentPrice > 0 ? Number(((currentPrice * shopeePct) / 100 + shopeeFixed).toFixed(2)) : 0;
    const shippingCost = 0;
    const netReceivable = currentPrice > 0 ? Number(Math.max(0, currentPrice - saleFeeAmount).toFixed(2)) : 0;

    return {
      platform: "shopee",
      external_id: externalId,
      title: title.trim(),
      current_price: currentPrice,
      original_price: originalPrice,
      seller_name: sellerName,
      seller_reputation: sellerReputation,
      seller_store_url: sellerStoreUrl,
      seller_id: sellerId,
      shipping_type: shippingType,
      promo_badge: promoBadge,
      permalink: normalizeUrl(window.location.href.split("?")[0]),
      thumbnail_url: thumbnailUrl,
      pictures: extractAllListingImages(),
      sales_count_approx: salesCount,
      listing_created_at: creationDate,
      listing_type: "shopee_padrao",
      listing_type_label: "Shopee Padrão",
      sale_fee_amount: saleFeeAmount,
      sale_fee_pct: shopeePct,
      shipping_cost: shippingCost,
      net_receivable: netReceivable,
      rating: 4.7,
    };
  }

  /**
   * Coleta mestre que invoca a rotina correspondente
   */
  function extractProductData() {
    if (isMercadoLivre) {
      return extractMercadoLivre();
    } else if (isShopee) {
      return extractShopee();
    }
    return null;
  }

  /**
   * Toast Corporativo no estilo Tiny ERP
   */
  function showToast(message, type = "info") {
    let toast = document.getElementById("crm-erp-toast");
    if (!toast) {
      toast = document.createElement("div");
      toast.id = "crm-erp-toast";
      toast.style.cssText = `
        position: fixed;
        bottom: 74px;
        right: 20px;
        z-index: 999999;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        font-size: 12px;
        line-height: 1.4;
        padding: 10px 14px;
        border-radius: 6px;
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2);
        display: flex;
        align-items: center;
        gap: 8px;
        transition: all 0.25s ease-in-out;
        max-width: 360px;
      `;
      document.body.appendChild(toast);
    }

    const colors = {
      success: { bg: "#ECFDF5", border: "#10B981", text: "#065F46" },
      error: { bg: "#FEF2F2", border: "#EF4444", text: "#991B1B" },
      info: { bg: "#F8FAFC", border: "#0284C7", text: "#0F172A" },
    };

    const style = colors[type] || colors.info;
    toast.style.backgroundColor = style.bg;
    toast.style.border = `1px solid ${style.border}`;
    toast.style.color = style.text;
    toast.innerHTML = `<strong>ERP Marketplaces:</strong> ${message}`;
    toast.style.opacity = "1";
    toast.style.transform = "translateY(0)";

    setTimeout(() => {
      if (toast) {
        toast.style.opacity = "0";
        toast.style.transform = "translateY(10px)";
      }
    }, 5000);
  }

  /**
   * Dispara a captura para o Service Worker
   */
  async function triggerCapture(myListingId = null, popupScrapedData = null) {
    let data = extractProductData();
    if (!data || !data.current_price) {
      showToast(
        "Não foi possível identificar o preço nesta página. Certifique-se de estar em um anúncio de produto.",
        "error"
      );
      return { success: false, error: "Preço não detectado na página" };
    }

    data = await refineMlCreationDateAsync(data);

    if (popupScrapedData && typeof popupScrapedData === "object") {
      if (typeof popupScrapedData.sale_fee_amount === "number" && popupScrapedData.sale_fee_amount > 0) {
        data.sale_fee_amount = popupScrapedData.sale_fee_amount;
      }
      if (typeof popupScrapedData.sale_fee_pct === "number" && popupScrapedData.sale_fee_pct > 0) {
        data.sale_fee_pct = popupScrapedData.sale_fee_pct;
      }
      if (typeof popupScrapedData.shipping_cost === "number" && popupScrapedData.shipping_cost >= 0) {
        data.shipping_cost = popupScrapedData.shipping_cost;
      }
      if (popupScrapedData.listing_type) {
        data.listing_type = popupScrapedData.listing_type;
      }
      if (popupScrapedData.listing_created_at) {
        data.listing_created_at = popupScrapedData.listing_created_at;
      }
    }

    // Se não foi passado diretamente, verifica no storage se há anúncio selecionado
    if (!myListingId && (chrome?.storage?.local || chrome?.storage?.sync)) {
      try {
        const localStored = await chrome.storage.local?.get(["selectedMyListingId"]);
        if (localStored?.selectedMyListingId) {
          myListingId = localStored.selectedMyListingId;
        } else {
          const syncStored = await chrome.storage.sync?.get(["selectedMyListingId"]);
          if (syncStored?.selectedMyListingId) {
            myListingId = syncStored.selectedMyListingId;
          }
        }
      } catch {
        // Ignora
      }
    }

    if (myListingId) {
      data.my_listing_id = myListingId;
    }

    showToast(`Coletando anúncio ${data.external_id} (R$ ${data.current_price.toFixed(2)})... Enviando ao CRM...`, "info");

    return new Promise((resolve) => {
      chrome.runtime.sendMessage(
        {
          action: "SYNC_COMPETITOR",
          payload: data,
        },
        (response) => {
          if (chrome.runtime.lastError) {
            const errMsg = chrome.runtime.lastError.message;
            showToast(`Erro de comunicação: ${errMsg}`, "error");
            return resolve({ success: false, error: errMsg });
          }

          if (response && response.success) {
            showToast(
              `Anúncio ${data.external_id} sincronizado com sucesso no ERP! Preço: R$ ${data.current_price.toFixed(2)}`,
              "success"
            );
            resolve({ success: true, data: response.data, item: data });
          } else {
            const errMsg = response?.error || "Verifique a URL do ERP no popup da extensão.";
            showToast(
              `Falha ao sincronizar: ${errMsg}`,
              "error"
            );
            resolve({ success: false, error: errMsg });
          }
        }
      );
    });
  }

  /**
   * Injeta Floating Action Button Discreto (Tiny ERP Style)
   * REQUISITO: O botão flutuante NÃO aparece por padrão para não cobrir o frete/botões do Mercado Livre.
   * O usuário pode ativá-lo se desejar pelo popup da extensão, e caso ativo, possui botão "✕" para fechar.
   */
  function injectFloatingButton() {
    if (!isProductPage()) return;

    // Se já estiver renderizado, não duplica
    if (document.getElementById("crm-erp-floating-container")) return;

    // Verifica preferência do usuário (padrão: false / desativado)
    const storage = chrome?.storage?.local || chrome?.storage?.sync;
    if (storage) {
      storage.get(["showFloatingBtn"], (res) => {
        // Se NÃO estiver explicitamente habilitado, não injeta
        if (!res || res.showFloatingBtn !== true) {
          const oldBtn = document.getElementById("crm-erp-floating-container") || document.getElementById("crm-erp-floating-btn");
          if (oldBtn) oldBtn.remove();
          return;
        }

        renderFloatingButtonWidget();
      });
    }
  }

  function renderFloatingButtonWidget() {
    if (document.getElementById("crm-erp-floating-container")) return;

    const container = document.createElement("div");
    container.id = "crm-erp-floating-container";
    container.style.cssText = `
      position: fixed;
      bottom: 24px;
      right: 24px;
      z-index: 999998;
      display: inline-flex;
      align-items: center;
      background-color: #0F172A;
      border: 1px solid #334155;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(15, 23, 42, 0.4);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      font-size: 12px;
      overflow: hidden;
      transition: all 0.2s ease;
    `;

    const btn = document.createElement("button");
    btn.id = "crm-erp-floating-btn";
    btn.innerHTML = `
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right:6px;">
        <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
      </svg>
      Capturar Concorrente (ERP)
    `;
    btn.style.cssText = `
      background: transparent;
      color: #FFFFFF;
      border: none;
      padding: 9px 14px;
      font-family: inherit;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      outline: none;
      transition: background-color 0.2s;
    `;

    btn.onmouseover = () => {
      btn.style.backgroundColor = "#1E293B";
    };
    btn.onmouseout = () => {
      btn.style.backgroundColor = "transparent";
    };

    btn.onclick = () => {
      chrome.storage.local?.get(["selectedMyListingId"], (localRes) => {
        if (localRes?.selectedMyListingId) {
          triggerCapture(localRes.selectedMyListingId);
        } else {
          chrome.storage.sync?.get(["selectedMyListingId"], (syncRes) => {
            triggerCapture(syncRes?.selectedMyListingId || null);
          });
        }
      });
    };

    // Botão para salvar anúncio na aba "Anúncios p/ Analisar & Criar"
    const saveOppBtn = document.createElement("button");
    saveOppBtn.id = "crm-erp-floating-save-btn";
    saveOppBtn.innerHTML = `🔖 Salvar p/ Criar`;
    saveOppBtn.title = "Salvar este anúncio na aba 'Anúncios p/ Analisar & Criar' do ERP";
    saveOppBtn.style.cssText = `
      background: transparent;
      color: #FBBF24;
      border: none;
      border-left: 1px solid #334155;
      padding: 9px 12px;
      font-family: inherit;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      outline: none;
      transition: background-color 0.2s;
    `;
    saveOppBtn.onmouseover = () => {
      saveOppBtn.style.backgroundColor = "#1E293B";
    };
    saveOppBtn.onmouseout = () => {
      saveOppBtn.style.backgroundColor = "transparent";
    };
    saveOppBtn.onclick = async () => {
      let data = extractProductData();
      if (!data || !data.current_price) {
        showToast("Não foi possível identificar o anúncio nesta página.", "error");
        return;
      }
      data = await refineMlCreationDateAsync(data);
      showToast(`Salvando "${(data.title || "").slice(0, 35)}..." em Anúncios p/ Criar...`, "info");
      chrome.runtime.sendMessage(
        {
          action: "SAVE_OPPORTUNITY_LISTING",
          payload: {
            external_id: data.external_id,
            platform: data.platform || "mercadolivre",
            title: data.title,
            current_price: data.current_price,
            original_price: data.original_price,
            discount_pct:
              data.original_price && data.original_price > data.current_price
                ? Math.round(((data.original_price - data.current_price) / data.original_price) * 100)
                : null,
            sales_count_approx: data.sales_count_approx || 0,
            listing_created_at: data.listing_created_at || null,
            seller_name: data.seller_name || null,
            seller_id: data.seller_id || null,
            seller_location: data.seller_location || null,
            seller_reputation: data.seller_reputation || null,
            seller_store_url: data.seller_store_url || null,
            shipping_type: data.shipping_type || "padrao",
            is_full: data.shipping_type === "ml_full",
            is_free_shipping: data.shipping_cost === 0,
            promo_badge: data.promo_badge || null,
            permalink: data.permalink || window.location.href,
            thumbnail_url: data.thumbnail_url || null,
            pictures: Array.isArray(data.pictures)
              ? data.pictures.map((p) => p?.primaryUrl || p?.originalUrl || p).filter(Boolean)
              : [],
            category_id: data.category_id || null,
            listing_type: data.listing_type || "gold_special",
            estimated_sale_fee: data.sale_fee_amount || 0,
            estimated_shipping_cost: data.shipping_cost || 0,
            estimated_net: data.net_receivable || 0,
            rating: data.rating || 4.8,
          },
        },
        (res) => {
          if (chrome.runtime.lastError || !res || !res.success) {
            showToast(`Erro ao salvar anúncio: ${res?.error || chrome.runtime.lastError?.message || "Falha"}`, "error");
          } else {
            saveOppBtn.innerHTML = "✓ Salvo p/ Criar!";
            saveOppBtn.style.color = "#34D399";
            showToast(`✓ Anúncio salvo em "Anúncios p/ Analisar & Criar" no ERP!`, "success");
          }
        }
      );
    };

    // Botão para baixar fotos do anúncio em JPG alta resolução
    const photoBtn = document.createElement("button");
    photoBtn.id = "crm-erp-floating-photo-btn";
    photoBtn.innerHTML = `
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right:5px;">
        <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/>
        <circle cx="12" cy="13" r="4"/>
      </svg>
      Baixar Fotos (JPG)
    `;
    photoBtn.title = "Baixar todas as fotos do anúncio em JPG na melhor qualidade";
    photoBtn.style.cssText = `
      background: transparent;
      color: #38BDF8;
      border: none;
      border-left: 1px solid #334155;
      padding: 9px 12px;
      font-family: inherit;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      outline: none;
      transition: background-color 0.2s;
    `;
    photoBtn.onmouseover = () => {
      photoBtn.style.backgroundColor = "#1E293B";
    };
    photoBtn.onmouseout = () => {
      photoBtn.style.backgroundColor = "transparent";
    };
    photoBtn.onclick = () => {
      triggerDownloadPhotosContentScript();
    };

    // Botão discreto para fechar e desativar o botão flutuante
    const closeBtn = document.createElement("button");
    closeBtn.id = "crm-erp-floating-close";
    closeBtn.innerHTML = "&times;";
    closeBtn.title = "Fechar e ocultar este botão (pode reativar no popup da extensão)";
    closeBtn.style.cssText = `
      background: transparent;
      color: #94A3B8;
      border: none;
      border-left: 1px solid #334155;
      padding: 9px 12px;
      font-size: 16px;
      font-weight: bold;
      line-height: 1;
      cursor: pointer;
      outline: none;
      transition: color 0.15s, background-color 0.15s;
    `;
    closeBtn.onmouseover = () => {
      closeBtn.style.color = "#FFFFFF";
      closeBtn.style.backgroundColor = "#EF4444";
    };
    closeBtn.onmouseout = () => {
      closeBtn.style.color = "#94A3B8";
      closeBtn.style.backgroundColor = "transparent";
    };

    closeBtn.onclick = (e) => {
      e.stopPropagation();
      container.remove();
      const storage = chrome?.storage?.local || chrome?.storage?.sync;
      if (storage) {
        storage.set({ showFloatingBtn: false });
      }
      showToast("Botão flutuante ocultado. Para reativar, abra o popup da extensão.", "info");
    };

    container.appendChild(btn);
    container.appendChild(saveOppBtn);
    container.appendChild(photoBtn);
    container.appendChild(closeBtn);
    document.body.appendChild(container);
  }

  async function triggerDownloadPhotosContentScript() {
    const data = extractProductData();
    const photos = data?.pictures && data.pictures.length > 0 ? data.pictures : extractAllListingImages();
    if (!photos || photos.length === 0) {
      showToast("Nenhuma foto encontrada para download neste anúncio.", "error");
      return;
    }

    const folderName = `Fotos_${data?.external_id || (isMercadoLivre ? "MercadoLivre" : "Shopee")}`;
    showToast(`Iniciando download de ${photos.length} fotos em JPG na melhor qualidade...`, "info");

    chrome.runtime.sendMessage(
      {
        action: "DOWNLOAD_PHOTOS",
        payload: {
          photos,
          folderName,
          title: data?.title || "",
          externalId: data?.external_id || "",
        },
      },
      (res) => {
        if (chrome.runtime.lastError || !res || !res.success) {
          showToast(`Falha no download das fotos: ${res?.error || chrome.runtime.lastError?.message || "Erro"}`, "error");
        } else {
          showToast(`✓ ${res.downloadedCount} fotos baixadas com sucesso em JPG na pasta Downloads (${folderName})!`, "success");
        }
      }
    );
  }

  // ==============================================================================
  // CAPTURA EM MASSA DE PÁGINAS DE PESQUISA (MERCADO LIVRE & SHOPEE)
  // ==============================================================================
  // ==============================================================================
  // CAPTURA EM MASSA DE PÁGINAS DE PESQUISA (MERCADO LIVRE & SHOPEE)
  // ==============================================================================
  function getAutoSyncParams() {
    const urlParams = new URLSearchParams(window.location.search);
    const hash = window.location.hash ? window.location.hash.substring(1) : "";
    const hashParams = new URLSearchParams(hash);

    const isAutoSync =
      urlParams.get("crm_auto_sync") === "1" ||
      urlParams.get("crm_sync") === "1" ||
      hashParams.get("crm_auto_sync") === "1" ||
      hashParams.get("crm_sync") === "1";

    let erpUrl = urlParams.get("erp_url") || hashParams.get("erp_url") || null;
    if (erpUrl) erpUrl = decodeURIComponent(erpUrl).trim().replace(/\/+$/, "");

    return { isAutoSync, erpUrl };
  }

  function isProductPage() {
    if (isMercadoLivre) {
      return (
        window.location.hostname.startsWith("produto.") ||
        /MLB-?\d+/i.test(window.location.pathname) ||
        !!document.querySelector(".ui-pdp-title, h1.ui-pdp-title, .ui-pdp-container, .ui-pdp-price")
      );
    }
    if (isShopee) {
      return (
        /-i\.\d+\.\d+/.test(window.location.pathname) ||
        !!document.querySelector(".page-product, ._44qnta, .f7A667")
      );
    }
    return false;
  }

  function isStorePage() {
    if (isProductPage()) return false;

    const host = window.location.hostname.toLowerCase();
    const url = window.location.href.toLowerCase();
    const path = window.location.pathname.toLowerCase();

    // MercadoShops e subdomínios oficiais de lojas (eshops / lojas)
    if (host.includes("mercadoshops.com.br") || host.startsWith("eshops.") || host.startsWith("loja.")) {
      return true;
    }

    if (!isMercadoLivre) return false;

    return (
      path.startsWith("/pagina/") ||
      path.startsWith("/loja/") ||
      path.startsWith("/perfil/") ||
      url.includes("/_custid_") ||
      url.includes("seller_id=") ||
      url.includes("client_id=") ||
      document.querySelector(
        ".ui-seller-data-header__title, .official-store-header, .store-info, [class*='seller-profile'], [class*='brand-header'], [class*='seller-header'], .brand-title, .ui-seller-data-header"
      ) !== null
    );
  }

  function cleanExtractedStoreName(raw) {
    if (!raw) return "";
    return String(raw)
      .replace(/^\s*\(\d+\+?\)\s*/i, "") // Remove badges de notificação da aba do navegador (ex: "(9+) Loja")
      .replace(/^(Loja\s+oficial|Vendido\s+por|Loja|Oficial|Por)\s*:?\s*/i, "")
      .replace(/^(?:Mais\s+)?An[uú]ncios?\s+(?:do\s+vendedor|da\s+loja|deste\s+vendedor)\s*:?\s*/i, "")
      .replace(/^Produtos?\s+(?:do\s+vendedor|da\s+loja)\s*:?\s*/i, "")
      .replace(/^Publicaci[oó]n(?:es)?\s+del\s+vendedor\s*:?\s*/i, "")
      .replace(/\s*\|\s*P[áa]gina\s+do\s+vendedor.*$/i, "")
      .replace(/\s+em\s+Mercado\s+Li[vb]re.*$/i, "")
      .replace(/\s*\|\s*Mercado\s+Li[vb]re.*$/i, "")
      .replace(/\s*-\s*Mercado\s+Li[vb]re.*$/i, "")
      .replace(/\s*no\s+Mercado\s+Li[vb]re.*$/i, "")
      .replace(/\s*em\s+um\s+s[óo]\s+lugar.*$/i, "")
      .replace(/\s+/g, " ")
      .trim();
  }

  function extractSellerNickname() {
    const m = window.location.pathname.match(/\/(?:pagina|loja|perfil)\/([^/?#]+)/i);
    if (m && m[1]) {
      return decodeURIComponent(m[1]).replace(/_Desde_\d+.*$/i, "").trim().toLowerCase();
    }
    // Subdomínios oficiais de eshops/lojas
    if (window.location.hostname.startsWith("eshops.") || window.location.hostname.startsWith("loja.")) {
      const parts = window.location.pathname.replace(/^\/+|\/+$/g, "").split("/");
      if (parts[0] && !parts[0].includes(".")) {
        return decodeURIComponent(parts[0]).replace(/_Desde_\d+.*$/i, "").trim().toLowerCase();
      }
    }
    return null;
  }

  function isGenericStoreTitle(val) {
    if (!val) return true;
    const t = cleanExtractedStoreName(val).toLowerCase().trim();
    if (t.length < 2) return true;
    // Nomes genéricos que NUNCA devem ser aceitos como nome comercial do concorrente
    if (
      /concorrente/i.test(t) ||
      /mercado\s*li[vb]re/i.test(t) ||
      /vendedor/i.test(t) ||
      /^(loja|loja\s+oficial|produtos|pagina|página|resultado|resultados|busca|loja\s+concorrente)$/i.test(t) ||
      /an[uú]ncios?\s+(do\s+vendedor|da\s+loja|deste\s+vendedor)/i.test(t) ||
      /produtos?\s+(do\s+vendedor|da\s+loja)/i.test(t) ||
      /publicaci[oó]n(?:es)?\s+del\s+vendedor/i.test(t) ||
      /frete\s+gr[áa]tis/i.test(t) ||
      /parcelamento\s+sem\s+juros/i.test(t)
    ) {
      return true;
    }
    return false;
  }

  function extractSellerFromCards(doc = document) {
    const sellerEls = Array.from(
      doc.querySelectorAll(".poly-component__seller, .ui-search-item__seller-info, [class*='seller-name'], [class*='seller-info']")
    );
    for (const el of sellerEls) {
      const candidate = cleanExtractedStoreName(el.innerText || el.textContent || "");
      if (candidate && !isGenericStoreTitle(candidate)) {
        return candidate;
      }
    }
    return null;
  }

  function extractStoreNameFromDoc(doc = document) {
    // 1. Seletores de cabeçalho de loja (incluindo h1.clipped da vitrine oficial moderna ML)
    const storeTitleEl = doc.querySelector(
      "h1.clipped, .ui-seller-data-header__title, .official-store-header h1, h1.store-header__title, .store-info__title, .header-store__title, h1.brand-title, .ui-pdp-seller__link-trigger, .ui-seller-data-header__brand-title, [data-testid='store-name'], [class*='seller-header'] h1, [class*='store-header'] h1, .ui-search-breadcrumb__title"
    );
    if (storeTitleEl) {
      const candidate = cleanExtractedStoreName(storeTitleEl.innerText || storeTitleEl.textContent || "");
      if (!isGenericStoreTitle(candidate)) return candidate;
    }

    // 2. Meta tags og:title / twitter:title / description da página do vendedor
    const ogTitle =
      doc.querySelector('meta[property="og:title"]')?.getAttribute("content") ||
      doc.querySelector('meta[name="twitter:title"]')?.getAttribute("content") ||
      doc.querySelector('meta[name="title"]')?.getAttribute("content");
    if (ogTitle && /em\s+Mercado\s+Li[vb]re|P[áa]gina\s+do\s+vendedor|Mercado\s+Li[vb]re/i.test(ogTitle)) {
      const candidate = cleanExtractedStoreName(ogTitle);
      if (!isGenericStoreTitle(candidate)) return candidate;
    }

    const metaDesc =
      doc.querySelector('meta[name="description"]')?.getAttribute("content") ||
      doc.querySelector('meta[property="og:description"]')?.getAttribute("content");
    if (metaDesc) {
      const descMatch = metaDesc.match(
        /encontre\s+todos\s+os\s+produtos\s+de\s+([^"'.]+?)\s+em\s+um\s+s[óo]\s+lugar/i
      );
      if (descMatch && descMatch[1]) {
        const candidate = cleanExtractedStoreName(descMatch[1]);
        if (!isGenericStoreTitle(candidate)) return candidate;
      }
    }

    // 3. Document Title (ex: "(9+) CARI-SOM | Página do vendedor" ou "HELIX SHIELD | Página do vendedor")
    const docTitle = doc.title || "";
    if (docTitle) {
      const titleCandidate = cleanExtractedStoreName(docTitle.split("|")[0].split(" - ")[0]);
      if (!isGenericStoreTitle(titleCandidate)) {
        return titleCandidate;
      }
    }

    // 4. Vendedor exibido nos próprios cards da vitrine/lista (.poly-component__seller)
    const cardSeller = extractSellerFromCards(doc);
    if (cardSeller && !isGenericStoreTitle(cardSeller)) {
      return cardSeller;
    }

    // 5. Inspeciona scripts internos da página por nickname ou store_name embutido
    try {
      const scripts = doc.querySelectorAll('script:not([src])');
      for (const s of scripts) {
        const txt = s.textContent || "";
        if (txt.includes("seller_name") || txt.includes("official_store_name") || txt.includes("brand_name") || txt.includes("eshop_name")) {
          const m = txt.match(/"(?:seller_name|official_store_name|brand_name|eshop_name)"\s*:\s*"([^"]{2,60})"/i);
          if (m && m[1]) {
            const cand = cleanExtractedStoreName(m[1]);
            if (cand && !isGenericStoreTitle(cand)) return cand;
          }
        }
      }
    } catch {}

    return null;
  }

  let __CACHED_STORE_NAME__ = null;

  function extractStoreName() {
    if (__CACHED_STORE_NAME__ && !isGenericStoreTitle(__CACHED_STORE_NAME__)) {
      return __CACHED_STORE_NAME__;
    }

    const fromDom = extractStoreNameFromDoc(document);
    if (fromDom && !isGenericStoreTitle(fromDom)) {
      __CACHED_STORE_NAME__ = fromDom;
      return fromDom;
    }

    // 1. Tenta extrair de cards de anúncios da página atual
    const cardSeller = extractSellerFromCards(document);
    if (cardSeller && !isGenericStoreTitle(cardSeller)) {
      __CACHED_STORE_NAME__ = cardSeller;
      return cardSeller;
    }

    // 2. Fallback intermediário: slug da URL formatado
    const slug = extractSellerNickname();
    if (slug) {
      const formatted = slug
        .replace(/[-_]+/g, " ")
        .trim()
        .split(" ")
        .map((w) => (w.length <= 3 ? w.toUpperCase() : w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()))
        .join(" ");
      __CACHED_STORE_NAME__ = formatted;
      return formatted;
    }

    // 3. Fallback por seller_id
    const sellerId = extractSellerId();
    if (sellerId) {
      return `Vendedor #${sellerId}`;
    }

    return "Loja Concorrente";
  }

  function extractSellerId() {
    // 1. URL pattern _CustId_
    const matchCustId = window.location.href.match(/_CustId_(\d+)/i);
    if (matchCustId) return matchCustId[1];

    // 2. Query param
    const matchParam = window.location.search.match(/[?&](?:seller_id|client_id)=(\d+)/i);
    if (matchParam) return matchParam[1];

    // 3. Meta or input
    const metaCust = document.querySelector('meta[name="seller-id"], input[name="seller_id"]');
    if (metaCust) {
      const val = metaCust.getAttribute("content") || metaCust.value;
      if (val && /^\d+$/.test(val)) return val;
    }

    // 4. Links na página contendo _CustId_ ou seller_id
    const sellerLink = document.querySelector('a[href*="_CustId_"], a[href*="seller_id="]');
    if (sellerLink) {
      const m = sellerLink.href.match(/_CustId_(\d+)/i) || sellerLink.href.match(/[?&]seller_id=(\d+)/i);
      if (m) return m[1];
    }

    // 5. Inspeciona scripts internos da página por seller_id, owner_id ou cust_id
    try {
      const htmlText = document.documentElement.innerHTML;
      const scriptMatch =
        htmlText.match(/"seller_id"\s*:\s*"?(\d{5,15})"?/i) ||
        htmlText.match(/\\"seller_id\\"\s*:\s*\\"?(\d{5,15})\\"?/i) ||
        htmlText.match(/"owner_id"\s*:\s*"?(\d{5,15})"?/i) ||
        htmlText.match(/\\"owner_id\\"\s*:\s*\\"?(\d{5,15})\\"?/i) ||
        htmlText.match(/"cust_id"\s*:\s*"?(\d{5,15})"?/i) ||
        htmlText.match(/_CustId_(\d{5,15})/i);
      if (scriptMatch && scriptMatch[1]) {
        return scriptMatch[1];
      }
    } catch {}

    return null;
  }

  async function resolveStoreNameAsync() {
    let current = extractStoreName();
    let slug = extractSellerNickname();
    const sellerId = extractSellerId();

    // Se o nome atual já for específico e não genérico nem igual ao slug puro
    if (current && !isGenericStoreTitle(current)) {
      const normCurrent = current.toLowerCase().replace(/[\s\-_]/g, "");
      const normSlug = (slug || "").toLowerCase().replace(/[\s\-_]/g, "");
      if (normCurrent !== normSlug) {
        return current;
      }
    }

    // 1. Tenta extrair da vitrine pública www.mercadolivre.com.br/pagina/<slug>
    if (slug) {
      try {
        const candidateUrls = [
          `https://www.mercadolivre.com.br/pagina/${encodeURIComponent(slug)}`,
          `https://www.mercadolivre.com.br/loja/${encodeURIComponent(slug)}`,
          `https://www.mercadolivre.com.br/perfil/${encodeURIComponent(slug)}`,
        ];
        for (const url of candidateUrls) {
          const controller = new AbortController();
          const timer = setTimeout(() => controller.abort(), 3500);
          const res = await fetch(url, {
            credentials: "omit",
            signal: controller.signal,
          });
          clearTimeout(timer);

          if (res.ok) {
            const html = await res.text();
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, "text/html");
            const realName = extractStoreNameFromDoc(doc);
            if (realName && !isGenericStoreTitle(realName)) {
              __CACHED_STORE_NAME__ = realName;
              return realName;
            }
          }
        }
      } catch (e) {
        console.warn("[resolveStoreNameAsync] Falha ao consultar vitrine do vendedor:", e);
      }
    }

    // 2. Fallback: extrai dos cards de anúncios da página atual
    const cardSeller = extractSellerFromCards(document);
    if (cardSeller && !isGenericStoreTitle(cardSeller)) {
      __CACHED_STORE_NAME__ = cardSeller;
      return cardSeller;
    }

    // 3. Se tiver slug, formata o nome de forma humanizada
    if (slug) {
      const formatted = slug
        .replace(/[-_]+/g, " ")
        .trim()
        .split(" ")
        .map((w) => (w.length <= 3 ? w.toUpperCase() : w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()))
        .join(" ");
      __CACHED_STORE_NAME__ = formatted;
      return formatted;
    }

    // 4. Se tiver sellerId
    if (sellerId) {
      return `Vendedor #${sellerId}`;
    }

    return "Loja Concorrente";
  }

  function extractStoreUrl() {
    return window.location.origin + window.location.pathname;
  }

  function extractTotalResultsCount(rootDoc = document) {
    const selectors = [
      ".ui-search-search-result__quantity-results",
      ".ui-search-results-total",
      "[class*='quantity-results']",
      ".ui-search-sidebar__title",
      "[class*='results-total']",
      ".ui-search-filter-dl",
    ];
    for (const sel of selectors) {
      const el = rootDoc.querySelector(sel);
      if (el && el.innerText) {
        const m = el.innerText.match(/(\d[\d\.]*)\s+resultados?/i);
        if (m) {
          const val = parseInt(m[1].replace(/\./g, ""), 10);
          if (!isNaN(val) && val > 0) return val;
        }
      }
    }
    const headerEl = rootDoc.querySelector(".ui-search-view-options, .ui-search-main, header, aside, .ui-search-layout");
    if (headerEl && headerEl.innerText) {
      const m = headerEl.innerText.match(/(\d[\d\.]*)\s+resultados?/i);
      if (m) {
        const val = parseInt(m[1].replace(/\./g, ""), 10);
        if (!isNaN(val) && val > 0) return val;
      }
    }
    return null;
  }

  function isSearchListingPage() {
    // Se for um anúncio individual de produto, NUNCA é página de busca
    if (isProductPage()) {
      return false;
    }

    if (isMercadoLivre) {
      const { isAutoSync } = getAutoSyncParams();
      return (
        isAutoSync ||
        window.location.hostname.includes("lista.mercadolivre.com.br") ||
        window.location.pathname.startsWith("/c/") ||
        window.location.search.includes("as_word=") ||
        window.location.search.includes("q=") ||
        document.querySelectorAll(
          "li.ui-search-layout__item, section.ui-search-results li, div.ui-search-result__wrapper"
        ).length >= 2
      );
    }
    if (isShopee) {
      return (
        window.location.pathname.includes("/search") ||
        window.location.search.includes("keyword=") ||
        document.querySelectorAll('div[data-sqe="item"]').length >= 5
      );
    }
    return false;
  }

  function extractSearchQuery() {
    if (isMercadoLivre) {
      const input = document.querySelector("input.nav-search-input") || document.querySelector('input[name="as_word"]');
      if (input && input.value) return input.value.trim();
      const pathParts = window.location.pathname.replace(/^\/+|\/+$/g, "").split("/");
      if (pathParts.length > 0 && !pathParts[0].includes(".html")) {
        return decodeURIComponent(pathParts[0]).replace(/-/g, " ").trim();
      }
    }
    if (isShopee) {
      const params = new URLSearchParams(window.location.search);
      if (params.get("keyword")) return params.get("keyword").trim();
      const input = document.querySelector("input.shopee-searchbar-input__input");
      if (input && input.value) return input.value.trim();
    }
    return document.title.split("|")[0].split("-")[0].trim() || "Produtos Pesquisados";
  }

  function extractAllSearchItems(rootDoc = document) {
    const items = [];
    const seenIds = new Set();
    const seenPermalinks = new Set();

    if (isMercadoLivre) {
      // Seleciona os cards reais evitando capturar simultaneamente container pai e filhos
      const rawElements = Array.from(rootDoc.querySelectorAll(
        "li.ui-search-layout__item, div.poly-card, div.ui-search-result, .shops__item, [data-component='poly-card'], .item-card, .promotion-item, .carousel__item"
      ));

      // Descarta LI se houver poly-card interno (processará o poly-card diretamente)
      const elements = rawElements.filter((el) => {
        if (el.tagName === "LI" && el.querySelector("div.poly-card, div.ui-search-result__wrapper")) {
          return false;
        }
        return true;
      });

      elements.forEach((el, index) => {
        try {
          const imgEl = el.querySelector("img");
          let thumbnail = null;
          if (imgEl) {
            thumbnail =
              imgEl.getAttribute("data-src") ||
              imgEl.src ||
              (imgEl.srcset ? imgEl.srcset.split(" ")[0] : null);
            if (thumbnail && (thumbnail.startsWith("data:") || thumbnail.includes("pixel.gif"))) {
              thumbnail = null;
            }
          }

          // Busca título garantindo que não seja badge de vendedor ou frete
          const titleEl = el.querySelector(
            "a.poly-component__title, .poly-component__title a, h2.poly-box a, h2 a, a.ui-search-item__group__element, [class*='title'] a, h2.ui-search-item__title, .ui-search-item__title, .poly-component__title"
          );
          let title = titleEl ? (titleEl.innerText || titleEl.textContent || "").trim() : (imgEl?.alt || "").trim();
          if (!title) return;

          // 1. Extração segura do link do produto (prioridade absoluta para a tag <a> do produto, nunca do vendedor)
          let linkEl = null;
          if (titleEl) {
            if (titleEl.tagName === "A" && titleEl.href && !titleEl.href.includes("/pagina/") && !titleEl.href.includes("/perfil/") && !titleEl.href.includes("/loja/")) {
              linkEl = titleEl;
            } else {
              const aInside = titleEl.querySelector("a");
              if (aInside && aInside.href && !aInside.href.includes("/pagina/") && !aInside.href.includes("/perfil/") && !aInside.href.includes("/loja/")) {
                linkEl = aInside;
              }
            }
          }
          if (!linkEl) {
            linkEl = el.querySelector(
              "a.poly-component__title, a[href*='/p/MLB'], a[href*='/MLB-'], a[href*='produto.mercadolivre.com.br/MLB'], a.ui-search-link"
            );
          }
          if (!linkEl) {
            const allLinks = Array.from(el.querySelectorAll("a[href*='MLB']"));
            linkEl = allLinks.find(a => !a.href.includes("/pagina/") && !a.href.includes("/perfil/") && !a.href.includes("/loja/")) || null;
          }
          if (!linkEl) linkEl = el.querySelector("a");
          if (!linkEl) return;

          let rawHref = linkEl.getAttribute("href") || linkEl.href || "";
          if (!rawHref) return;
          if (rawHref.startsWith("//")) {
            rawHref = `https:${rawHref}`;
          } else if (rawHref.startsWith("/")) {
            rawHref = `https://produto.mercadolivre.com.br${rawHref}`;
          } else if (!rawHref.startsWith("http://") && !rawHref.startsWith("https://")) {
            rawHref = `https://produto.mercadolivre.com.br/${rawHref}`;
          }

          // Se for link patrocinado do Mercado Clics (click1.mercadolivre.com.br), desempacota a URL real do produto
          if (rawHref.includes("click1.mercadolivre.com.br") || rawHref.includes("/mclics/")) {
            try {
              const u = new URL(rawHref, "https://www.mercadolivre.com.br");
              const target = u.searchParams.get("url") || u.searchParams.get("tu");
              if (target) rawHref = decodeURIComponent(target);
            } catch {}
          }

          let permalink = rawHref.split("#")[0];
          const isCatalog = permalink.includes("/p/MLB") || permalink.includes("/p/");
          const sellerId = extractSellerId();

          // Se for produto de catálogo (/p/MLB...), inclui ou preserva o seller_id para abrir direto na Buy Box do concorrente
          try {
            const u = new URL(permalink, "https://www.mercadolivre.com.br");
            if (isCatalog && sellerId && !u.search.includes("seller_id")) {
              u.searchParams.set("pdp_filters", `seller_id:${sellerId}`);
              permalink = u.toString();
            } else if (!isCatalog) {
              // Limpa parâmetros transitórios de busca que quebram links externos
              permalink = `${u.origin}${u.pathname}`;
            }
          } catch {}

          const cleanLink = permalink.split("?")[0].replace(/\/+$/, "");

          const widMatch =
            permalink.match(/(MLB-?\d+)/i) ||
            el.innerHTML.match(/wid=(MLB\d+)/i) ||
            permalink.match(/\/p\/(MLB\d+)/i);
          const external_id = widMatch ? widMatch[1].replace("-", "") : `MLB${Date.now()}_${index}`;

          // DEDUPLICAÇÃO ESTRITA: impede duplicação do mesmo anúncio no card/página
          if (seenIds.has(external_id)) return;
          if (cleanLink && seenPermalinks.has(cleanLink)) return;
          seenIds.add(external_id);
          if (cleanLink) seenPermalinks.add(cleanLink);

          // Preço Atual
          let current_price = 0;
          const priceFrac = el.querySelector(
            ".poly-price__amount .andes-money-amount__fraction, .andes-money-amount__fraction"
          );
          const priceCents = el.querySelector(
            ".poly-price__amount .andes-money-amount__cents, .andes-money-amount__cents"
          );
          if (priceFrac) {
            const frac = parseFloat(priceFrac.innerText.replace(/\./g, "").trim());
            const cent = priceCents ? parseFloat(priceCents.innerText.trim()) / 100 : 0;
            current_price = frac + cent;
          }

          if (!current_price || isNaN(current_price)) {
            const priceTextMatch = el.innerText.match(/R\$\s*([\d\.,]+)/);
            if (priceTextMatch) {
              current_price = parseBrlCurrency(priceTextMatch[1]);
            }
          }

          if (!current_price || isNaN(current_price)) return;

          // Preço Original & Desconto
          const prevFrac = el.querySelector(
            ".andes-money-amount--previous .andes-money-amount__fraction, s .andes-money-amount__fraction"
          );
          const original_price = prevFrac ? parseFloat(prevFrac.innerText.replace(/\./g, "").trim()) : null;

          const discountEl = el.querySelector(".poly-price__discount-polylabel, .andes-money-amount__discount");
          let discountPct = discountEl ? parseInt(discountEl.innerText.replace(/[^\d]/g, ""), 10) || null : null;
          if (!discountPct && original_price && original_price > current_price) {
            discountPct = Math.round(((original_price - current_price) / original_price) * 100);
          }

          const is_full = /full/i.test(el.innerHTML) && (el.querySelector("svg") !== null || el.innerText.includes("FULL"));
          const is_free_shipping = /frete grátis/i.test(el.innerText) || /chegará grátis/i.test(el.innerText);

          const promoEl = el.querySelector("[class*='polylabel']");
          const promo_badge = promoEl ? promoEl.innerText.trim() : (discountPct ? `${discountPct}% OFF` : is_full ? "FULL" : null);

          const sellerEl = el.querySelector(".poly-component__seller, .ui-search-item__seller-info, [class*='seller']");
          const seller_name = sellerEl ? sellerEl.innerText.replace(/^Por\s+/i, "").trim() : "Vendedor Mercado Livre";

          const ratingEl = el.querySelector(".poly-component__review-compacted, .poly-reviews__rating");
          let rating = ratingEl ? parseFloat(ratingEl.innerText.replace(",", ".")) : 4.8;
          if (isNaN(rating)) rating = 4.8;

          // Vendas aproximadas (0 se não houver vendas registradas no card)
          const soldMatch = el.innerText.match(/(\+?\d+(?:[\.,]\d+)?)\s*(mil|k)?\s*vendid/i);
          let sales_count = 0;
          if (soldMatch) {
            let num = parseFloat(soldMatch[1].replace("+", "").replace(/\./g, "").replace(",", "."));
            if (soldMatch[2] && (soldMatch[2].toLowerCase().startsWith("mil") || soldMatch[2].toLowerCase() === "k")) num *= 1000;
            if (!isNaN(num) && num >= 0) sales_count = Math.round(num);
          }

          const listing_created_at = interpolateMlbCreationDate(external_id, thumbnail);

          // Estima taxa de venda e frete grátis preliminares
          const resolvedListingType = is_full ? "gold_pro" : "gold_special";
          const feePct = resolvedListingType === "gold_pro" ? 0.17 : 0.12;
          const fixedFee = current_price < 79 ? 6.0 : 0;
          const estFee = Number(((current_price * feePct) + fixedFee).toFixed(2));
          let estShipping = 0;
          if (current_price >= 79) {
            if (current_price < 100) estShipping = 13.65;
            else if (current_price < 120) estShipping = 16.85;
            else if (current_price < 150) estShipping = 18.65;
            else if (current_price < 200) estShipping = 20.45;
            else estShipping = 22.45;
          }
          const estNet = Math.max(0, Number((current_price - estFee - estShipping).toFixed(2)));

          items.push({
            id: external_id,
            platform: "mercadolivre",
            external_id,
            title,
            current_price: Number(current_price.toFixed(2)),
            original_price: original_price ? Number(original_price.toFixed(2)) : null,
            discount_pct: discountPct,
            shipping_type: is_full ? "ml_full" : is_free_shipping ? "ml_correios" : "padrao",
            is_free_shipping,
            is_full_or_flex: is_full,
            promo_badge,
            campaign_type: promo_badge ? "Campanha ML" : null,
            listing_type: resolvedListingType,
            permalink,
            thumbnail_url: thumbnail,
            seller_name,
            seller_reputation: "platinum",
            sales_count_approx: sales_count,
            listing_created_at,
            rating,
            reviews_count: sales_count > 0 ? Math.min(500, Math.round(sales_count * 0.15) + 5) : 0,
            is_already_monitored: false,
            matched_my_listing_id: null,
            is_catalog: isCatalog,
            estimated_sale_fee: estFee,
            estimated_shipping: estShipping,
            estimated_net: estNet,
          });
        } catch (e) {
          console.warn("[ERP Extractor] Erro em item ML:", e);
        }
      });
    } else if (isShopee) {
      const elements = document.querySelectorAll('div[data-sqe="item"], div.shopee-search-item-result__item, a[data-sqe="link"]');
      elements.forEach((el, index) => {
        try {
          const linkEl = el.tagName === "A" ? el : el.querySelector("a[href*='/product/']") || el.querySelector("a");
          if (!linkEl) return;
          const rawHref = linkEl.getAttribute("href") || "";
          const permalink = rawHref.startsWith("http") ? rawHref : `https://shopee.com.br${rawHref}`;

          const imgEl = el.querySelector("img");
          const thumbnail = imgEl ? (imgEl.src || imgEl.getAttribute("data-src")) : null;

          const titleEl = el.querySelector('div[data-sqe="name"], [class*="name"], [class*="title"]') || imgEl;
          const title = titleEl ? (titleEl.innerText || titleEl.alt || "").trim() : "";
          if (!title) return;

          const priceText = el.innerText;
          const priceMatch = priceText.match(/R\$\s*([\d\.,]+)/i);
          let current_price = priceMatch ? parseBrlCurrency(priceMatch[1]) : 0;
          if (!current_price) return;

          const soldMatch = priceText.match(/(\d+(?:[\.,]\d+)?)\s*(mil|k)?\s*vendid/i);
          let sales_count = 0;
          if (soldMatch) {
            let num = parseFloat(soldMatch[1].replace(/\./g, "").replace(",", "."));
            if (soldMatch[2] && (soldMatch[2].toLowerCase().startsWith("mil") || soldMatch[2].toLowerCase() === "k")) num *= 1000;
            sales_count = Math.round(num);
          }

          const external_id = `SHP_${Date.now()}_${index}`;

          items.push({
            id: external_id,
            platform: "shopee",
            external_id,
            title,
            current_price: Number(current_price.toFixed(2)),
            original_price: null,
            discount_pct: null,
            shipping_type: "shopee_xpress",
            is_free_shipping: true,
            is_full_or_flex: true,
            promo_badge: "Destaque Shopee",
            campaign_type: "Ofertas Shopee",
            listing_type: "oficial",
            permalink,
            thumbnail_url: thumbnail,
            seller_name: "Vendedor Shopee",
            seller_reputation: "indicado",
            sales_count_approx: sales_count || 120,
            rating: 4.8,
            reviews_count: Math.round((sales_count || 120) * 0.2),
            is_already_monitored: false,
            matched_my_listing_id: null,
          });
        } catch (e) {
          console.warn("[ERP Extractor] Erro em item Shopee:", e);
        }
      });
    }
    return items;
  }

  /**
   * Helper para obter a URL do ERP configurada
   */
  async function resolveErpUrl(overrideUrl = null) {
    if (overrideUrl) return overrideUrl;
    const { erpUrl: paramUrl } = getAutoSyncParams();
    if (paramUrl) return paramUrl;

    return new Promise((resolve) => {
      chrome.storage.local?.get(["erpUrl"], (localData) => {
        chrome.storage.sync?.get(["erpUrl"], (syncData) => {
          let url = (localData?.erpUrl || syncData?.erpUrl || "").trim().replace(/\/+$/, "");
          if (!url) url = "http://localhost:3000";
          resolve(url);
        });
      });
    });
  }

  /**
   * Envia os itens coletados para o ERP via bulk-sync
   */
  async function sendItemsToErp(overrideUrl = null) {
    const items = extractAllSearchItems();
    if (items.length === 0) {
      throw new Error("Nenhum anúncio localizado na página atual.");
    }

    const query = extractSearchQuery();
    const erpUrl = await resolveErpUrl(overrideUrl);
    const platform = isMercadoLivre ? "mercadolivre" : "shopee";

    const payload = {
      query,
      platform,
      items,
    };

    let result = null;

    // 1. Tenta sincronizar primeiro via Background Service Worker da extensão
    // (completamente imune a CORS, CSP ou bloqueios de página)
    try {
      if (typeof chrome !== "undefined" && chrome.runtime?.sendMessage) {
        result = await new Promise((resolve, reject) => {
          chrome.runtime.sendMessage(
            {
              action: "SYNC_SEARCH_ITEMS",
              erpUrl,
              payload,
            },
            (response) => {
              if (chrome.runtime.lastError) {
                return reject(new Error(chrome.runtime.lastError.message));
              }
              if (response && response.success) {
                return resolve(response);
              }
              return reject(new Error(response?.error || "Falha no background worker"));
            }
          );
        });
      }
    } catch (bgErr) {
      console.warn("[AutoSync] Falha via background worker, tentando fetch direto:", bgErr);
    }

    // 2. Se não executou pelo background worker, faz fetch direto
    if (!result) {
      const response = await fetch(`${erpUrl}/api/bi/market-search/bulk-sync`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error(`Erro HTTP ${response.status} ao sincronizar com ${erpUrl}`);
      }

      const json = await response.json();
      result = {
        success: true,
        count: items.length,
        query,
        erpUrl,
        redirectUrl: json.redirectUrl || `/inteligencia?q=${encodeURIComponent(query)}&platform=${platform}`,
      };
    }

    // Notifica em tempo real a aba do ERP aberta no navegador
    try {
      if (typeof BroadcastChannel !== "undefined") {
        const channel = new BroadcastChannel("crm_market_search_channel");
        channel.postMessage({
          type: "SYNC_COMPLETED",
          query,
          count: items.length,
          platform,
        });
        setTimeout(() => channel.close(), 1000);
      }
    } catch (bcErr) {
      console.warn("BroadcastChannel error:", bcErr);
    }

    return result;
  }

  /**
   * Exibe toast flutuante no topo/canto da página
   */
  function showFloatingNotification(msg, status = "info", erpUrl = null, redirectUrl = null) {
    let box = document.getElementById("crm-floating-notification");
    if (!box) {
      box = document.createElement("div");
      box.id = "crm-floating-notification";
      box.style.position = "fixed";
      box.style.top = "20px";
      box.style.right = "20px";
      box.style.zIndex = "9999999";
      box.style.borderRadius = "10px";
      box.style.padding = "12px 18px";
      box.style.fontSize = "13px";
      box.style.fontFamily = "-apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif";
      box.style.boxShadow = "0 10px 35px rgba(0,0,0,0.3)";
      box.style.display = "flex";
      box.style.alignItems = "center";
      box.style.gap = "12px";
      box.style.transition = "all 0.3s ease";
      document.body.appendChild(box);
    }

    if (status === "loading") {
      box.style.backgroundColor = "#0F172A";
      box.style.color = "#FFFFFF";
      box.style.border = "1px solid #334155";
      box.innerHTML = `
        <span style="display:inline-block;animation:spin 1s linear infinite;">⚡</span>
        <span style="font-weight:600;">${msg}</span>
      `;
    } else if (status === "success") {
      box.style.backgroundColor = "#064E3B";
      box.style.color = "#ECFDF5";
      box.style.border = "1px solid #10B981";
      box.innerHTML = `
        <span style="font-weight:bold;font-size:16px;">✓</span>
        <span style="font-weight:600;">${msg}</span>
        ${
          erpUrl && redirectUrl
            ? `<a href="${erpUrl}${redirectUrl}" target="_blank" style="background:#10B981;color:#FFFFFF;text-decoration:none;padding:6px 12px;border-radius:6px;font-weight:700;font-size:11px;margin-left:6px;">Ver no ERP →</a>`
            : ""
        }
        <button id="crm-close-toast" style="background:transparent;border:none;color:#A7F3D0;cursor:pointer;font-size:16px;margin-left:4px;">✕</button>
      `;
      const btn = document.getElementById("crm-close-toast");
      if (btn) btn.onclick = () => box.remove();
      setTimeout(() => {
        if (box && box.parentElement) box.remove();
      }, 7000);
    } else {
      box.style.backgroundColor = "#7F1D1D";
      box.style.color = "#FEF2F2";
      box.style.border = "1px solid #EF4444";
      box.innerHTML = `
        <span>⚠️</span>
        <span style="font-weight:600;">${msg}</span>
        <button id="crm-close-toast" style="background:transparent;border:none;color:#FECACA;cursor:pointer;font-size:16px;margin-left:4px;">✕</button>
      `;
      const btn = document.getElementById("crm-close-toast");
      if (btn) btn.onclick = () => box.remove();
    }
  }

  /**
   * Injeta barra de sincronização quando estiver em página de pesquisa
   */
  function injectSearchSyncFloatingBar() {
    if (!isSearchListingPage()) return;
    if (document.getElementById("crm-marketplaces-search-bar")) return;

    const items = extractAllSearchItems();
    if (items.length === 0) return;

    const query = extractSearchQuery();
    const bar = document.createElement("div");
    bar.id = "crm-marketplaces-search-bar";
    bar.style.position = "fixed";
    bar.style.bottom = "24px";
    bar.style.right = "24px";
    bar.style.zIndex = "999999";
    bar.style.backgroundColor = "#0F172A";
    bar.style.color = "#FFFFFF";
    bar.style.borderRadius = "12px";
    bar.style.padding = "12px 18px";
    bar.style.boxShadow = "0 8px 30px rgba(0, 0, 0, 0.4)";
    bar.style.fontFamily = "-apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif";
    bar.style.fontSize = "12px";
    bar.style.display = "flex";
    bar.style.alignItems = "center";
    bar.style.gap = "14px";
    bar.style.border = "1px solid #334155";
    bar.style.transition = "all 0.2s ease";

    bar.innerHTML = `
      <div style="display:flex;align-items:center;gap:8px;">
        <span style="background-color:#4F46E5;color:#FFFFFF;padding:3px 8px;border-radius:6px;font-weight:700;font-size:10px;">ERP INTELIGÊNCIA</span>
        <span style="font-weight:600;color:#F8FAFC;">${items.length} anúncios detectados para &quot;${query}&quot;</span>
      </div>
      <button id="crm-sync-search-btn" style="background-color:#4F46E5;color:#FFFFFF;border:none;border-radius:8px;padding:8px 14px;font-size:11px;font-weight:700;cursor:pointer;display:flex;align-items:center;gap:6px;transition:background-color 0.2s;">
        🚀 Enviar Pesquisa para o ERP
      </button>
      <button id="crm-close-search-bar" style="background:transparent;border:none;color:#94A3B8;cursor:pointer;font-size:16px;line-height:1;padding:0 4px;margin-left:4px;">
        ✕
      </button>
    `;

    document.body.appendChild(bar);

    const closeBtn = document.getElementById("crm-close-search-bar");
    if (closeBtn) {
      closeBtn.onclick = () => {
        bar.remove();
      };
    }

    const syncBtn = document.getElementById("crm-sync-search-btn");
    if (syncBtn) {
      syncBtn.onclick = async () => {
        syncBtn.innerText = "Enviando dados ao ERP...";
        syncBtn.style.opacity = "0.7";
        syncBtn.disabled = true;

        try {
          const res = await sendItemsToErp();
          bar.innerHTML = `
            <div style="display:flex;align-items:center;gap:8px;">
              <span style="color:#10B981;font-weight:700;font-size:14px;">✓</span>
              <span style="font-weight:600;color:#F8FAFC;">${res.count} anúncios sincronizados no ERP!</span>
            </div>
            <a href="${res.erpUrl}${res.redirectUrl}" target="_blank" style="background-color:#10B981;color:#FFFFFF;text-decoration:none;border-radius:8px;padding:8px 14px;font-size:11px;font-weight:700;display:inline-block;">
              Ver Análise Completa no ERP →
            </a>
            <button id="crm-close-search-bar-2" style="background:transparent;border:none;color:#94A3B8;cursor:pointer;font-size:16px;line-height:1;padding:0 4px;margin-left:4px;">
              ✕
            </button>
          `;
          const closeBtn2 = document.getElementById("crm-close-search-bar-2");
          if (closeBtn2) closeBtn2.onclick = () => bar.remove();
        } catch (err) {
          console.error(err);
          alert(`Falha ao sincronizar com o ERP: ${err.message}`);
          syncBtn.innerText = "Tentar Novamente";
          syncBtn.disabled = false;
          syncBtn.style.opacity = "1";
        }
      };
    }
  }

  /**
   * Envia payload da loja diretamente ao ERP (via background worker ou fetch direto)
   */
  async function sendStorePayloadToErp(erpUrl, payload) {
    let result = null;
    try {
      if (typeof chrome !== "undefined" && chrome.runtime?.sendMessage) {
        result = await new Promise((resolve, reject) => {
          chrome.runtime.sendMessage(
            { action: "SYNC_STORE_ITEMS", erpUrl, payload },
            (response) => {
              if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
              if (response && response.success) return resolve(response);
              return reject(new Error(response?.error || "Falha no background worker"));
            }
          );
        });
      }
    } catch (bgErr) {
      console.warn("[AutoSync Store] Tentando fetch direto após worker:", bgErr);
    }

    if (!result) {
      const response = await fetch(`${erpUrl}/api/competitors/stores/sync`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error(`Erro HTTP ${response.status} ao sincronizar loja com o ERP`);
      }

      const json = await response.json();
      result = {
        success: true,
        count: payload.items?.length || 0,
        storeName: payload.store_name,
        erpUrl,
        redirectUrl: "/inteligencia?tab=lojas",
        ...json,
      };
    }

    return result;
  }

  /**
   * Encontra a URL da próxima página de resultados da loja (DOM + Offset ML)
   */
  /**
   * Encontra a URL da próxima página de resultados da loja com validação Anti-Drift e Offset Seguro do ML
   */
  function findNextPageUrl(nextPageNum, crawl = null) {
    const expectedSellerId = crawl?.sellerId || extractSellerId();
    const expectedSlug = crawl?.slug || extractSellerNickname();

    // 1. Procura STRICTLY dentro do container de paginação principal (NUNCA em carrosséis ou links soltos)
    const paginationContainer = document.querySelector(
      ".ui-search-pagination, nav.andes-pagination, ul.andes-pagination, .andes-pagination"
    );

    if (paginationContainer) {
      const nextSelectors = [
        "li.andes-pagination__button--next a",
        "li.andes-pagination__button--next span a",
        "a.andes-pagination__link[title*='Seguinte' i]",
        "a.andes-pagination__link[title*='Próxim' i]",
        "a[title*='Página seguinte' i]",
        "a[title*='Página próxima' i]",
        "a[title*='Siguiente' i]",
        "a.andes-pagination__arrow--next",
        "a[rel='next']",
        `a.andes-pagination__link[data-page='${nextPageNum}']`,
      ];

      for (const sel of nextSelectors) {
        const el = paginationContainer.querySelector(sel);
        if (el) {
          let h = el.getAttribute("href") || el.href;
          if (h && !h.startsWith("#") && !h.startsWith("javascript:")) {
            if (h.startsWith("/")) h = `${window.location.origin}${h}`;

            // Validação Anti-Drift: garante que o link NÃO aponta para outra loja/categoria ou carrossel
            try {
              const targetUrl = new URL(h);
              if (targetUrl.hostname.includes("mercadolivre.com.br")) {
                const targetSellerId = (h.match(/_CustId_(\d+)/i) || h.match(/[?&]seller_id=(\d+)/i))?.[1];
                if (expectedSellerId && targetSellerId && targetSellerId !== expectedSellerId) {
                  console.warn("[Crawler] Link descartado por pertencer a outro vendedor:", targetSellerId);
                  continue;
                }
                const targetSlug = h.match(/\/(?:pagina|loja)\/([^/?#]+)/i)?.[1];
                if (expectedSlug && targetSlug && targetSlug.toLowerCase() !== expectedSlug.toLowerCase()) {
                  console.warn("[Crawler] Link descartado por pertencer a outro slug:", targetSlug);
                  continue;
                }
                if (/\/ajuda|\/login|\/registration|\/gz\//i.test(targetUrl.pathname)) {
                  continue;
                }
                return h;
              }
            } catch {}
          }
        }
      }
    }

    // 2. Fallback matemático ROBUSTO pelo offset oficial do Mercado Livre (_Desde_)
    const offset = (nextPageNum - 1) * 48 + 1;
    try {
      // Se sabemos o sellerId, a rota canônica mais universal e livre de 404 do Mercado Livre é _CustId_:
      if (expectedSellerId) {
        return `https://lista.mercadolivre.com.br/_CustId_${expectedSellerId}_Desde_${offset}_NoIndex_True`;
      }

      const u = new URL(window.location.href);
      let p = u.pathname;

      if (p.includes("_Desde_")) {
        p = p.replace(/_Desde_\d+/, `_Desde_${offset}`);
      } else {
        // Remove barras finais para NÃO criar rota inválida /_Desde_49
        p = p.replace(/\/+$/, "");
        p = `${p}_Desde_${offset}_NoIndex_True`;
      }
      u.pathname = p;
      return u.toString();
    } catch {
      return null;
    }
  }

  /**
   * Executa etapa da varredura automática entre páginas
   */
  async function handleStoreCrawlStep(crawl) {
    // Expira após 5 minutos de inatividade
    if (Date.now() - crawl.startedAt > 5 * 60 * 1000) {
      await chrome.storage.local.remove("crm_store_crawl");
      injectStoreSyncFloatingBar();
      return;
    }

    // Anti-Drift Guard: se a página atual navegou para outra loja ou página inválida, aborta o desvio com segurança
    const currentSlug = extractSellerNickname();
    const currentSellerId = extractSellerId();
    if (crawl.sellerId && currentSellerId && currentSellerId !== crawl.sellerId) {
      console.warn("[Crawler] Desvio detectado: página atual é do sellerId", currentSellerId, "esperado:", crawl.sellerId);
      await chrome.storage.local.remove("crm_store_crawl");
      renderCrawlFinishedSuccess(crawl, await resolveErpUrl());
      return;
    }
    if (crawl.slug && currentSlug && currentSlug.toLowerCase() !== crawl.slug.toLowerCase()) {
      console.warn("[Crawler] Desvio detectado: página atual é do slug", currentSlug, "esperado:", crawl.slug);
      await chrome.storage.local.remove("crm_store_crawl");
      renderCrawlFinishedSuccess(crawl, await resolveErpUrl());
      return;
    }

    renderCrawlProgressBar(crawl);

    // Aguarda cards carregarem na página atual
    await new Promise((r) => setTimeout(r, 600));

    const pageItems = extractAllSearchItems();
    const seenIds = new Set((crawl.accumulatedItems || []).map((i) => i.external_id));
    let newItemsCount = 0;
    for (const it of pageItems) {
      if (!seenIds.has(it.external_id)) {
        seenIds.add(it.external_id);
        crawl.accumulatedItems.push(it);
        newItemsCount++;
      }
    }

    const erpUrl = await resolveErpUrl();
    const payload = {
      platform: "mercadolivre",
      store_name: crawl.storeName,
      seller_id: crawl.sellerId,
      seller_nickname: crawl.slug || null,
      store_url: crawl.storeUrl,
      segment: crawl.segment || "Acessórios Automotivos",
      is_following: true,
      seller_reputation: "platinum",
      total_listings: crawl.totalExpected,
      items: crawl.accumulatedItems,
    };

    try {
      await sendStorePayloadToErp(erpUrl, payload);
    } catch (err) {
      console.warn("[Crawler] Erro ao sincronizar lote:", err);
    }

    updateCrawlProgressUI(crawl);

    const isFinished =
      crawl.accumulatedItems.length >= crawl.totalExpected ||
      crawl.currentPage >= 20 ||
      (newItemsCount === 0 && crawl.currentPage > 1);

    if (!isFinished) {
      const nextUrl = findNextPageUrl(crawl.currentPage + 1, crawl);
      if (nextUrl) {
        crawl.currentPage++;
        await chrome.storage.local.set({ crm_store_crawl: crawl });
        const statusEl = document.getElementById("crm-crawler-status");
        if (statusEl) {
          statusEl.innerText = `Avançando para página ${crawl.currentPage}...`;
        }
        setTimeout(() => {
          window.location.href = nextUrl;
        }, 800);
        return;
      }
    }

    // Finalizado
    await chrome.storage.local.remove("crm_store_crawl");
    renderCrawlFinishedSuccess(crawl, erpUrl);
  }

  function renderCrawlProgressBar(crawl) {
    if (document.getElementById("crm-crawler-bar")) return;
    const bar = document.createElement("div");
    bar.id = "crm-crawler-bar";
    bar.style.position = "fixed";
    bar.style.top = "16px";
    bar.style.left = "50%";
    bar.style.transform = "translateX(-50%)";
    bar.style.zIndex = "9999999";
    bar.style.backgroundColor = "#0F172A";
    bar.style.color = "#FFFFFF";
    bar.style.border = "2px solid #6366F1";
    bar.style.borderRadius = "14px";
    bar.style.padding = "12px 22px";
    bar.style.boxShadow = "0 10px 40px rgba(0,0,0,0.6)";
    bar.style.display = "flex";
    bar.style.alignItems = "center";
    bar.style.gap = "18px";
    bar.style.fontFamily = "-apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif";
    bar.style.fontSize = "13px";

    const totalPages = Math.ceil(crawl.totalExpected / 48) || 1;
    const pct = Math.min(100, Math.round(((crawl.accumulatedItems?.length || 0) / crawl.totalExpected) * 100));

    bar.innerHTML = `
      <div style="display:flex;align-items:center;gap:10px;">
        <div style="width:12px;height:12px;border-radius:50%;background:#10B981;box-shadow:0 0 10px #10B981;"></div>
        <div>
          <div style="font-weight:700;color:#F8FAFC;">Varredura Automática: ${crawl.storeName}</div>
          <div id="crm-crawler-status" style="font-size:11px;color:#94A3B8;">Página ${crawl.currentPage} de ~${totalPages} • <strong style="color:#60A5FA;">${crawl.accumulatedItems?.length || 0} de ${crawl.totalExpected}</strong> coletados</div>
        </div>
      </div>
      <div style="width:160px;height:8px;background:#1E293B;border-radius:4px;overflow:hidden;border:1px solid #334155;">
        <div id="crm-crawler-fill" style="width:${pct}%;height:100%;background:linear-gradient(90deg, #4F46E5, #3B82F6);transition:width 0.3s ease;"></div>
      </div>
      <button id="crm-cancel-crawl-btn" style="background:#EF4444;color:#FFFFFF;border:none;border-radius:6px;padding:6px 12px;font-size:11px;font-weight:700;cursor:pointer;">
        ✕ Cancelar
      </button>
    `;

    document.body.appendChild(bar);

    const cancelBtn = document.getElementById("crm-cancel-crawl-btn");
    if (cancelBtn) {
      cancelBtn.onclick = async () => {
        await chrome.storage.local.remove("crm_store_crawl");
        bar.remove();
        alert("Varredura cancelada. Os anúncios já coletados foram preservados no ERP.");
      };
    }
  }

  function updateCrawlProgressUI(crawl) {
    const statusEl = document.getElementById("crm-crawler-status");
    const fillEl = document.getElementById("crm-crawler-fill");
    const totalPages = Math.ceil(crawl.totalExpected / 48) || 1;
    const pct = Math.min(100, Math.round(((crawl.accumulatedItems?.length || 0) / crawl.totalExpected) * 100));
    if (statusEl) {
      statusEl.innerHTML = `Página ${crawl.currentPage} de ~${totalPages} • <strong style="color:#60A5FA;">${crawl.accumulatedItems?.length || 0} de ${crawl.totalExpected}</strong> coletados`;
    }
    if (fillEl) {
      fillEl.style.width = `${pct}%`;
    }
  }

  function renderCrawlFinishedSuccess(crawl, erpUrl) {
    const existing = document.getElementById("crm-crawler-bar");
    if (existing) existing.remove();

    const bar = document.createElement("div");
    bar.id = "crm-crawler-finished-bar";
    bar.style.position = "fixed";
    bar.style.top = "16px";
    bar.style.left = "50%";
    bar.style.transform = "translateX(-50%)";
    bar.style.zIndex = "9999999";
    bar.style.backgroundColor = "#0F172A";
    bar.style.color = "#FFFFFF";
    bar.style.border = "2px solid #10B981";
    bar.style.borderRadius = "14px";
    bar.style.padding = "14px 22px";
    bar.style.boxShadow = "0 10px 40px rgba(0,0,0,0.6)";
    bar.style.display = "flex";
    bar.style.alignItems = "center";
    bar.style.gap = "18px";
    bar.style.fontFamily = "-apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif";
    bar.style.fontSize = "13px";

    bar.innerHTML = `
      <span style="font-size:22px;">🎉</span>
      <div>
        <div style="font-weight:700;color:#10B981;font-size:14px;">Varredura Concluída com Sucesso!</div>
        <div style="font-size:12px;color:#E2E8F0;">Todos os <strong>${crawl.accumulatedItems?.length || 0} anúncios</strong> da loja &quot;${crawl.storeName}&quot; foram salvos no ERP.</div>
      </div>
      <a href="${erpUrl}/inteligencia?tab=lojas" target="_blank" style="background:#10B981;color:#FFFFFF;text-decoration:none;border-radius:8px;padding:8px 16px;font-size:12px;font-weight:700;display:inline-block;">
        Ver Loja no ERP →
      </a>
      <button id="crm-close-crawler-finished" style="background:transparent;border:none;color:#94A3B8;cursor:pointer;font-size:16px;margin-left:4px;">✕</button>
    `;

    document.body.appendChild(bar);

    const closeBtn = document.getElementById("crm-close-crawler-finished");
    if (closeBtn) {
      closeBtn.onclick = () => bar.remove();
    }
  }

  /**
   * Envia apenas os anúncios visíveis da página atual da loja para o ERP
   */
  async function sendStoreToErp(overrideUrl = null, segment = "Acessórios Automotivos", isFollowing = true) {
    const items = extractAllSearchItems();
    if (items.length === 0) {
      throw new Error("Nenhum anúncio localizado na loja do concorrente.");
    }

    const totalExpected = extractTotalResultsCount() || items.length;
    const storeName = await resolveStoreNameAsync();
    const sellerId = extractSellerId();
    const sellerNickname = extractSellerNickname();
    const storeUrl = extractStoreUrl();
    const erpUrl = await resolveErpUrl(overrideUrl);

    const payload = {
      platform: "mercadolivre",
      store_name: storeName,
      seller_id: sellerId,
      seller_nickname: sellerNickname,
      store_url: storeUrl,
      segment: segment || "Acessórios Automotivos",
      is_following: isFollowing,
      seller_reputation: "platinum",
      total_listings: totalExpected > items.length ? totalExpected : items.length,
      items,
    };

    return await sendStorePayloadToErp(erpUrl, payload);
  }

  /**
   * Injeta barra de sincronização quando estiver na página de loja/vendedor concorrente
   */
  async function injectStoreSyncFloatingBar() {
    if (!isStorePage()) return;
    if (document.getElementById("crm-marketplaces-store-bar") || document.getElementById("crm-crawler-bar")) return;

    // Se houver uma sessão de varredura automática ativa, continua o fluxo
    try {
      const crawlStorage = await chrome.storage.local.get("crm_store_crawl");
      const crawl = crawlStorage?.crm_store_crawl;
      if (crawl && crawl.active) {
        handleStoreCrawlStep(crawl);
        return;
      }
    } catch {}

    const items = extractAllSearchItems();
    const storeName = await resolveStoreNameAsync();
    const totalCount = extractTotalResultsCount() || items.length;

    const countText = totalCount > items.length
      ? `${totalCount} anúncios (${items.length} nesta página)`
      : `${totalCount} anúncios`;

    const bar = document.createElement("div");
    bar.id = "crm-marketplaces-store-bar";
    bar.style.position = "fixed";
    bar.style.bottom = "24px";
    bar.style.right = "24px";
    bar.style.zIndex = "999999";
    bar.style.backgroundColor = "#0F172A";
    bar.style.color = "#FFFFFF";
    bar.style.borderRadius = "12px";
    bar.style.padding = "12px 18px";
    bar.style.boxShadow = "0 8px 30px rgba(0, 0, 0, 0.4)";
    bar.style.fontFamily = "-apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif";
    bar.style.fontSize = "12px";
    bar.style.display = "flex";
    bar.style.alignItems = "center";
    bar.style.gap = "14px";
    bar.style.border = "1px solid #4338CA";
    bar.style.transition = "all 0.2s ease";

    const buttonLabel = totalCount > items.length
      ? `🚀 Iniciar Varredura de Todos os ${totalCount} Anúncios`
      : `📥 Capturar Loja (${totalCount} anúncios) para o ERP`;

    bar.innerHTML = `
      <div style="display:flex;align-items:center;gap:8px;">
        <span style="background:linear-gradient(135deg, #4F46E5, #6366F1);color:#FFFFFF;padding:3px 8px;border-radius:6px;font-weight:700;font-size:10px;">🏪 CONCORRENTE DETECTADO</span>
        <span style="font-weight:600;color:#F8FAFC;">${storeName} • <strong>${countText}</strong></span>
      </div>
      <button id="crm-sync-store-btn" style="background:linear-gradient(135deg, #4338CA, #6366F1);color:#FFFFFF;border:none;border-radius:8px;padding:8px 14px;font-size:11px;font-weight:700;cursor:pointer;display:flex;align-items:center;gap:6px;transition:opacity 0.2s;">
        ${buttonLabel}
      </button>
      <button id="crm-close-store-bar" style="background:transparent;border:none;color:#94A3B8;cursor:pointer;font-size:16px;line-height:1;padding:0 4px;margin-left:4px;">
        ✕
      </button>
    `;

    document.body.appendChild(bar);

    const closeBtn = document.getElementById("crm-close-store-bar");
    if (closeBtn) closeBtn.onclick = () => bar.remove();

    const syncBtn = document.getElementById("crm-sync-store-btn");
    if (syncBtn) {
      syncBtn.onclick = async () => {
        syncBtn.innerText = "Iniciando varredura da loja...";
        syncBtn.style.opacity = "0.7";
        syncBtn.disabled = true;

        try {
          if (totalCount > items.length) {
            const sellerId = extractSellerId();
            const sellerNickname = extractSellerNickname();

            // Inicia crawl de múltiplas páginas com navegação real
            const crawl = {
              active: true,
              storeName,
              storeUrl: extractStoreUrl(),
              sellerId: sellerId,
              slug: sellerNickname,
              totalExpected: totalCount,
              currentPage: 1,
              accumulatedItems: items,
              startedAt: Date.now(),
              segment: "Acessórios Automotivos",
            };

            const erpUrl = await resolveErpUrl();
            const payload = {
              platform: "mercadolivre",
              store_name: storeName,
              seller_id: crawl.sellerId,
              seller_nickname: crawl.slug || null,
              store_url: crawl.storeUrl,
              segment: "Acessórios Automotivos",
              is_following: true,
              seller_reputation: "platinum",
              total_listings: totalCount,
              items,
            };

            await sendStorePayloadToErp(erpUrl, payload);
            await chrome.storage.local.set({ crm_store_crawl: crawl });

            const nextUrl = findNextPageUrl(2, crawl);
            if (nextUrl) {
              syncBtn.innerText = `Pág. 1 salva (${items.length}/${totalCount}). Avançando...`;
              setTimeout(() => {
                window.location.href = nextUrl;
              }, 700);
              return;
            }
          }

          // Loja de 1 página só:
          const res = await sendStoreToErp();
          bar.innerHTML = `
            <div style="display:flex;align-items:center;gap:8px;">
              <span style="color:#10B981;font-weight:700;font-size:14px;">✓</span>
              <span style="font-weight:600;color:#F8FAFC;">${res.count} anúncios da loja &quot;${storeName}&quot; sincronizados no ERP!</span>
            </div>
            <a href="${res.erpUrl}${res.redirectUrl}" target="_blank" style="background-color:#10B981;color:#FFFFFF;text-decoration:none;border-radius:8px;padding:8px 14px;font-size:11px;font-weight:700;display:inline-block;">
              Analisar Concorrente no ERP →
            </a>
            <button id="crm-close-store-bar-2" style="background:transparent;border:none;color:#94A3B8;cursor:pointer;font-size:16px;line-height:1;padding:0 4px;margin-left:4px;">
              ✕
            </button>
          `;
          const closeBtn2 = document.getElementById("crm-close-store-bar-2");
          if (closeBtn2) closeBtn2.onclick = () => bar.remove();
        } catch (err) {
          console.error(err);
          alert(`Falha ao sincronizar loja com o ERP: ${err.message}`);
          syncBtn.innerText = "Tentar Novamente";
          syncBtn.disabled = false;
          syncBtn.style.opacity = "1";
        }
      };
    }
  }

  // Listener para requisições vindas do popup
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "GET_PAGE_DATA") {
      if (isStorePage()) {
        const searchItems = extractAllSearchItems();
        resolveStoreNameAsync().then((resolvedStoreName) => {
          sendResponse({
            success: true,
            isStore: true,
            isSearch: false,
            storeName: resolvedStoreName,
            sellerNickname: extractSellerNickname(),
            storeUrl: extractStoreUrl(),
            sellerId: extractSellerId(),
            itemsCount: searchItems.length,
            platform: "mercadolivre",
          });
        });
        return true;
      }
      const isSearch = isSearchListingPage();
      if (isSearch) {
        const searchItems = extractAllSearchItems();
        sendResponse({
          success: true,
          isStore: false,
          isSearch: true,
          query: extractSearchQuery(),
          itemsCount: searchItems.length,
          platform: isMercadoLivre ? "mercadolivre" : "shopee",
        });
      } else {
        const rawData = extractProductData();
        refineMlCreationDateAsync(rawData)
          .then((data) => {
            sendResponse({ success: true, isStore: false, isSearch: false, data });
          })
          .catch(() => {
            sendResponse({ success: true, isStore: false, isSearch: false, data: rawData });
          });
      }
      return true;
    }

    if (request.action === "SYNC_STORE_FROM_POPUP") {
      const storeUrl = extractStoreUrl();
      const sellerId = extractSellerId();
      const sellerNickname = extractSellerNickname();
      const items = extractAllSearchItems();
      resolveStoreNameAsync().then((storeName) => {
        sendResponse({
          success: true,
          storeName,
          sellerNickname,
          storeUrl,
          sellerId,
          items,
          platform: "mercadolivre",
        });
      });
      return true;
    }

    if (request.action === "GET_LISTING_IMAGES") {
      const rawData = extractProductData();
      const pictures =
        rawData?.pictures && rawData.pictures.length > 0 ? rawData.pictures : extractAllListingImages();
      sendResponse({
        success: true,
        pictures,
        title: rawData?.title || "",
        external_id: rawData?.external_id || "",
        platform: isMercadoLivre ? "mercadolivre" : "shopee",
      });
      return true;
    }

    if (request.action === "SYNC_SEARCH_FROM_POPUP") {
      const query = extractSearchQuery();
      const items = extractAllSearchItems();
      sendResponse({ success: true, query, items, platform: isMercadoLivre ? "mercadolivre" : "shopee" });
      return true;
    }

    if (request.action === "TRIGGER_CAPTURE_FROM_POPUP") {
      triggerCapture(request.my_listing_id, request.scraped_data || null)
        .then((result) => {
          sendResponse(result || { success: true });
        })
        .catch((err) => {
          sendResponse({ success: false, error: err.message });
        });
      return true;
    }
  });

  // Salva no storage caso tenha recebido erp_url no hash ou query params
  const { isAutoSync, erpUrl: initialErpUrl } = getAutoSyncParams();
  if (initialErpUrl) {
    try {
      chrome.storage?.local?.set({ erpUrl: initialErpUrl });
      chrome.storage?.sync?.set({ erpUrl: initialErpUrl });
    } catch {}
  }

  // Disparo automático caso requisitado pelo ERP (crm_auto_sync=1)
  if (isAutoSync) {
    showFloatingNotification("⚡ Coletando anúncios automaticamente para o ERP...", "loading");
    setTimeout(async () => {
      try {
        const result = await sendItemsToErp(initialErpUrl);
        showFloatingNotification(
          `✅ ${result.count} anúncios de "${result.query}" enviados ao ERP!`,
          "success",
          result.erpUrl,
          result.redirectUrl
        );
      } catch (e) {
        console.warn("[ERP AutoSync] Falha inicial, aguardando carregamento dos cards:", e);
        setTimeout(async () => {
          try {
            const retryRes = await sendItemsToErp(initialErpUrl);
            showFloatingNotification(
              `✅ ${retryRes.count} anúncios de "${retryRes.query}" enviados ao ERP!`,
              "success",
              retryRes.erpUrl,
              retryRes.redirectUrl
            );
          } catch (retryErr) {
            showFloatingNotification(`Falha ao sincronizar: ${retryErr.message}`, "error");
          }
        }, 1500);
      }
    }, 1000);
  }

  // Se estiver em modo de varredura ativa de loja, retoma a captura imediatamente
  if (typeof chrome !== "undefined" && chrome.storage?.local) {
    chrome.storage.local.get("crm_store_crawl").then((res) => {
      const crawl = res?.crm_store_crawl;
      if (crawl && crawl.active) {
        handleStoreCrawlStep(crawl);
      }
    }).catch(() => {});
  }

  // Aguarda DOM estabilizar e injeta os botões corretos
  setTimeout(() => {
    if (isStorePage()) {
      injectStoreSyncFloatingBar();
    } else if (isSearchListingPage()) {
      injectSearchSyncFloatingBar();
    } else {
      injectFloatingButton();
    }
  }, 1200);

  // Monitora alterações de URL em SPAs
  let lastUrl = window.location.href;
  setInterval(() => {
    if (window.location.href !== lastUrl) {
      lastUrl = window.location.href;
      setTimeout(() => {
        if (isStorePage()) {
          injectStoreSyncFloatingBar();
        } else if (isSearchListingPage()) {
          injectSearchSyncFloatingBar();
        } else {
          injectFloatingButton();
        }
      }, 1000);
    }
  }, 1500);
})();


